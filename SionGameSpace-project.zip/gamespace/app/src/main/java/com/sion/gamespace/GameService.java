package com.sion.gamespace;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Pemantau latar: mengenali game, menerapkan mode, menjalankan HUD/panel, mencatat sesi. */
public class GameService extends Service implements Overlay.Host {
    static final String ACT_START = "start";
    static final String ACT_STOP = "stop";
    static final String ACT_PREVIEW = "preview";
    static final String ACT_REFRESH = "refresh";

    private static final String CH_RUN = "gs_run";
    private static final String CH_REP = "gs_rep";
    private static final int NID_RUN = 1;
    private static final int NID_REP = 2;

    private static volatile GameService instance;

    static GameService get() { return instance; }

    private Store store;
    private Overlay overlay;
    private HandlerThread thread;
    private Handler loop;
    private final ExecutorService actions = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile boolean running;

    // keadaan game (hanya diubah dari thread loop kecuali ditandai volatile)
    private volatile String game;
    private volatile String gameName = "";
    private volatile String mode = "turbo";
    private int missCount;
    private int sample;
    private int hot;
    private long tickNo;

    // keadaan ubin
    private volatile boolean focusOn, wifiOn, brightOn, recOn;
    private volatile int refreshIdx;
    private volatile List<String> rateList = new ArrayList<String>();
    private volatile String ramSub = "";

    // sesi
    private long sStart;
    private long fpsSum;
    private int fpsN;
    private int maxTemp;
    private int batStart = -1;
    private int batNow = -1;
    private long pingSum;
    private int pingN;
    private final List<Float> frameTimes = new ArrayList<Float>();
    private volatile int lastPing = -1;
    private long prevIdle = -1, prevTotal = -1;
    private int pingSkip;
    private String sessionMode = "";

    // ------------------------------------------------------------ siklus hidup

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        store = new Store(this);
        overlay = new Overlay(this, this, store);
        createChannels();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent == null ? ACT_START : intent.getAction();
        if (act == null) act = ACT_START;
        startForeground(NID_RUN, runNotification(getString(R.string.app_name), "Siaga. Buka game untuk mulai."));
        if (ACT_STOP.equals(act)) {
            shutdown();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) startLoop();
        if (ACT_PREVIEW.equals(act)) overlay.preview();
        if (ACT_REFRESH.equals(act)) overlay.refreshHud();
        return START_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        shutdown();
        actions.shutdown();
        instance = null;
        super.onDestroy();
    }

    boolean isRunning() { return running; }

    String activeGame() { return game; }

    private void startLoop() {
        running = true;
        thread = new HandlerThread("gs-loop");
        thread.start();
        loop = new Handler(thread.getLooper());
        loop.post(new Runnable() {
            @Override public void run() {
                Gs.ensure(GameService.this);
                Gs.sh(GameService.this, 1, "restore");
                loadRates();
                schedule(0);
            }
        });
    }

    private void schedule(long delay) {
        if (!running || loop == null) return;
        loop.postDelayed(new Runnable() {
            @Override public void run() { tick(); }
        }, delay);
    }

    private void shutdown() {
        if (!running) { overlay.hideAll(); return; }
        running = false;
        final Handler l = loop;
        final HandlerThread t = thread;
        if (l != null) {
            l.removeCallbacksAndMessages(null);
            l.post(new Runnable() {
                @Override public void run() {
                    if (game != null) endSession(false);
                    t.quitSafely();
                }
            });
        }
        overlay.hideAll();
    }

    // ------------------------------------------------------------ loop

    private boolean screenOn() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        return pm == null || pm.isInteractive();
    }

    private void tick() {
        if (!running) return;
        long next = 2000;
        try {
            tickNo++;
            if (!RootShell.get(1).isRoot()) {
                if (tickNo % 5 == 1) {
                    boolean ok = RootShell.get(1).recheck();
                    updateRun(ok ? "Siaga. Buka game untuk mulai." : "Akses root belum diberikan.");
                }
                schedule(4000);
                return;
            }
            if (!screenOn()) { schedule(4000); return; }
            if (game == null) {
                detect();
                next = 2000;
            } else {
                // dalam game: ukur tiap 1 detik jika HUD/panel tampil, selain itu tiap 3 detik
                boolean fast = overlay.isPanelOpen() || store.cfg().optBoolean("hud", true);
                if (tickNo % 2 == 0) detect();
                if (game != null && (fast || tickNo % 3 == 0)) measure();
                next = fast ? 1000 : 1500;
            }
        } catch (RuntimeException e) {
            // jangan biarkan satu galat mematikan pemantau
        }
        schedule(next);
    }

    private static boolean ignored(String p) {
        return p == null || p.length() == 0 || p.equals("com.android.systemui") || p.equals(Gs.PKG)
                || p.contains("inputmethod") || p.contains(".ime") || p.equals("android");
    }

    private void detect() {
        String fg = Gs.sh(this, 1, "fg").trim();
        if (ignored(fg)) return;
        boolean isGame = Gs.validPkg(fg) && store.hasGame(fg);
        if (isGame) {
            missCount = 0;
            if (!fg.equals(game)) {
                if (game != null) endSession(true);
                startSession(fg);
            }
        } else if (game != null) {
            missCount++;
            if (missCount >= 2) endSession(true);
        }
    }

    // ------------------------------------------------------------ sesi

    private JSONObject gameConf(String pkg) {
        JSONObject g = store.games().optJSONObject(pkg);
        return g == null ? new JSONObject() : g;
    }

    private String dash(String s) { return s == null || s.length() == 0 ? "-" : s; }

    private void startSession(String pkg) {
        JSONObject cfg = store.cfg();
        JSONObject conf = gameConf(pkg);
        game = pkg;
        gameName = conf.optString("name", pkg);
        String m = conf.optString("mode", "");
        mode = Gs.normMode(m.length() == 0 ? cfg.optString("defaultMode", "turbo") : m);
        sessionMode = mode;
        resetSession();
        applyCurrent();
        overlay.showHandles(gameName);
        updateRun(gameName + " • mode " + Gs.modeName(mode));
        if (cfg.optBoolean("haptic", true)) overlay.toast("Sion Game Space aktif • " + Gs.modeName(mode));
    }

    private void resetSession() {
        sStart = System.currentTimeMillis();
        fpsSum = 0; fpsN = 0; maxTemp = 0; batStart = -1; batNow = -1;
        pingSum = 0; pingN = 0; frameTimes.clear();
        sample = 0; hot = 0; missCount = 0; lastPing = -1; prevIdle = -1; prevTotal = -1;
        focusOn = false; wifiOn = false; brightOn = false; refreshIdx = 0; recOn = false;
    }

    /** Terapkan mode saat ini ke game aktif lewat skrip root. */
    private void applyCurrent() {
        final String pkg = game;
        if (pkg == null) return;
        JSONObject cfg = store.cfg();
        JSONObject conf = gameConf(pkg);
        boolean focus = cfg.optBoolean("focus", true) && conf.optBoolean("focus", true);
        String side = "edge".equals(cfg.optString("edgeMode", "edge")) ? cfg.optString("side", "right") : "none";
        String args = "apply " + mode + " " + pkg + " " + (focus ? "1" : "0") + " "
                + dash(clean(conf.optString("down", ""))) + " " + dash(clean(conf.optString("fps", ""))) + " "
                + dash(clean(conf.optString("refresh", ""))) + " " + side;
        Gs.sh(this, 0, args);
        focusOn = focus;
        brightOn = focus;
        wifiOn = "tourney".equals(mode);
        refreshIdx = 0;
    }

    private String clean(String s) { return Gs.validNum(s) ? s : ""; }

    private void endSession(boolean notify) {
        final String pkg = game;
        if (pkg == null) return;
        long dur = (System.currentTimeMillis() - sStart) / 1000;
        if (recOn) { Gs.sh(this, 0, "rec stop"); recOn = false; }
        Gs.sh(this, 0, "restore");
        final String name = gameName;
        final int avg = fpsN > 0 ? (int) (fpsSum / fpsN) : 0;
        final int low = low1();
        final int drop = batStart >= 0 && batNow >= 0 ? Math.max(0, batStart - batNow) : 0;
        final int ping = pingN > 0 ? (int) (pingSum / pingN) : -1;
        final int tmax = maxTemp;
        game = null;
        gameName = "";
        missCount = 0;
        overlay.hideAll();
        if (dur >= 20) {
            try {
                JSONObject s = new JSONObject();
                s.put("pkg", pkg);
                s.put("name", name);
                s.put("start", sStart);
                s.put("dur", dur);
                s.put("avg", avg);
                s.put("low", low);
                s.put("temp", tmax);
                s.put("drop", drop);
                s.put("ping", ping);
                s.put("mode", sessionMode);
                store.addSession(s);
            } catch (JSONException ignored) { }
            if (notify) postReport(name, dur, avg, low, tmax, drop);
        }
        updateRun("Siaga. Buka game untuk mulai.");
    }

    private int low1() {
        int n = frameTimes.size();
        if (n < 30) return 0;
        Float[] a = frameTimes.toArray(new Float[0]);
        Arrays.sort(a);
        float p99 = a[Math.min(n - 1, (int) (n * 0.99f))];
        return p99 > 0 ? Math.round(1000f / p99) : 0;
    }

    // ------------------------------------------------------------ pengukuran

    private void measure() {
        final String pkg = game;
        if (pkg == null) return;
        Metrics m = Metrics.parse(Gs.sh(this, 1, "metrics " + pkg));
        sample++;
        if (prevTotal >= 0 && m.cpuTotal > prevTotal) {
            float dt = m.cpuTotal - prevTotal;
            float di = m.cpuIdle - prevIdle;
            m.cpuLoad = Math.max(0f, Math.min(100f, 100f * (1f - di / dt)));
        }
        prevIdle = m.cpuIdle;
        prevTotal = m.cpuTotal;
        m.ping = lastPing;
        if (m.fps > 0) { fpsSum += m.fps; fpsN++; }
        for (float f : m.ft) if (f > 0 && frameTimes.size() < 6000) frameTimes.add(f);
        if (m.temp() > maxTemp) maxTemp = m.temp();
        if (m.bat >= 0) { if (batStart < 0) batStart = m.bat; batNow = m.bat; }
        if (lastPing >= 0 && sample % 3 == 0) { pingSum += lastPing; pingN++; }
        if (sample == 3 || sample == 10) Gs.sh(this, 1, "protect " + pkg);
        if (sample % 3 == 1) pingAsync();
        overlay.bind(m);
        thermalGuard(m);
    }

    private void pingAsync() {
        final String host = store.cfg().optString("pingHost", "1.1.1.1");
        if (!host.matches("[A-Za-z0-9.\\-]{1,100}")) return;
        if (pingSkip > 0) { pingSkip--; return; }
        actions.execute(new Runnable() {
            @Override public void run() {
                String r = Gs.sh(GameService.this, 0, "ping " + host).trim();
                try { lastPing = Math.round(Float.parseFloat(r)); } catch (NumberFormatException e) { lastPing = -1; pingSkip = 5; }
            }
        });
    }

    private void thermalGuard(Metrics m) {
        JSONObject cfg = store.cfg();
        if (!cfg.optBoolean("guard", true)) return;
        if (!("turbo".equals(mode) || "tourney".equals(mode))) { hot = 0; return; }
        int limit = cfg.optInt("guardTemp", 48);
        if (m.temp() >= limit) hot++; else hot = 0;
        if (hot >= 3) {
            hot = 0;
            mode = "balance";
            applyCurrent();
            overlay.toast("Suhu " + m.temp() + "° • mode diturunkan ke Seimbang");
            overlay.refreshPanel();
            updateRun(gameName + " • mode Seimbang (suhu tinggi)");
        }
    }

    private void loadRates() {
        String r = Gs.sh(this, 0, "rates").trim();
        List<String> l = new ArrayList<String>();
        l.add("auto");
        for (String s : r.split(",")) if (s.matches("[0-9]{2,3}")) l.add(s);
        rateList = l;
    }

    // ------------------------------------------------------------ Overlay.Host

    @Override
    public void setMode(final String id) {
        final String nm = Gs.normMode(id);
        mode = nm;
        hot = 0;
        if (game == null) { overlay.toast("Mode " + Gs.modeName(nm)); return; }
        actions.execute(new Runnable() {
            @Override public void run() {
                applyCurrent();
                updateRun(gameName + " • mode " + Gs.modeName(nm));
                overlay.toast("Mode " + Gs.modeName(nm));
                overlay.refreshPanel();
            }
        });
    }

    @Override
    public void tile(final String id) {
        if ("settings".equals(id)) { openApp(); closePanel(); return; }
        if (game == null) { overlay.toast("Contoh tampilan. Buka game untuk memakai aksi ini."); return; }
        overlay.setBusyTile(id, true);
        actions.execute(new Runnable() {
            @Override public void run() {
                try { doTile(id); } finally { overlay.setBusyTile(id, false); overlay.refreshPanel(); }
            }
        });
    }

    private void doTile(String id) {
        if ("focus".equals(id)) {
            boolean to = !focusOn;
            Gs.sh(this, 0, "focus " + (to ? "on" : "off"));
            focusOn = to;
            brightOn = to;
            overlay.toast(to ? "Mode fokus aktif" : "Mode fokus mati");
        } else if ("ram".equals(id)) {
            java.util.Map<String, String> r = Gs.kv(Gs.sh(this, 0, "ram"));
            String mb = r.get("ram_free_mb");
            ramSub = mb == null ? "" : mb + " MB";
            overlay.toast(mb == null ? "RAM dibersihkan" : "RAM bebas " + mb + " MB");
        } else if ("shot".equals(id)) {
            java.util.Map<String, String> r = Gs.kv(Gs.sh(this, 0, "shot"));
            String f = r.get("shot");
            overlay.toast(f != null && f.startsWith("/") ? "Foto disimpan di Pictures/GameSpace" : "Foto gagal diambil");
        } else if ("rec".equals(id)) {
            if (!recOn) {
                Gs.sh(this, 0, "rec start");
                recOn = true;
                overlay.toast("Merekam layar (maks 3 menit)");
            } else {
                Gs.sh(this, 0, "rec stop");
                recOn = false;
                overlay.toast("Rekaman disimpan di Movies/GameSpace");
            }
        } else if ("refresh".equals(id)) {
            List<String> l = rateList;
            if (l.size() < 2) { overlay.toast("Layar ini hanya punya satu laju segar"); return; }
            int next = (refreshIdx + 1) % l.size();
            Gs.sh(this, 0, "refresh " + l.get(next));
            refreshIdx = next;
            overlay.toast(next == 0 ? "Laju segar otomatis" : "Laju segar " + l.get(next) + " Hz");
        } else if ("wifi".equals(id)) {
            boolean to = !wifiOn;
            Gs.sh(this, 0, "wifi " + (to ? "on" : "off"));
            wifiOn = to;
            overlay.toast(to ? "Wi-Fi latensi rendah aktif" : "Wi-Fi kembali normal");
        } else if ("bright".equals(id)) {
            boolean to = !brightOn;
            Gs.sh(this, 0, "bright " + (to ? "on" : "off"));
            brightOn = to;
            overlay.toast(to ? "Kecerahan dikunci" : "Kecerahan otomatis");
        }
    }

    @Override
    public boolean tileOn(String id) {
        if ("focus".equals(id)) return focusOn;
        if ("wifi".equals(id)) return wifiOn;
        if ("bright".equals(id)) return brightOn;
        if ("rec".equals(id)) return recOn;
        if ("refresh".equals(id)) return refreshIdx > 0;
        return false;
    }

    @Override
    public String tileSub(String id) {
        if ("refresh".equals(id)) {
            List<String> l = rateList;
            if (refreshIdx > 0 && refreshIdx < l.size()) return l.get(refreshIdx) + " Hz";
            return "Auto";
        }
        if ("ram".equals(id)) return ramSub;
        if ("focus".equals(id)) return focusOn ? "Aktif" : "";
        if ("rec".equals(id)) return recOn ? "Merekam" : "";
        return "";
    }

    @Override public String activeMode() { return mode; }

    @Override
    public void openApp() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try { startActivity(i); } catch (RuntimeException ignored) { }
    }

    @Override public void closePanel() { overlay.closePanel(); }

    @Override public void onPanelState(boolean open) { }

    // ------------------------------------------------------------ notifikasi

    private void createChannels() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel run = new NotificationChannel(CH_RUN, "Status Game Space", NotificationManager.IMPORTANCE_LOW);
        run.setShowBadge(false);
        nm.createNotificationChannel(run);
        NotificationChannel rep = new NotificationChannel(CH_REP, "Laporan sesi", NotificationManager.IMPORTANCE_DEFAULT);
        nm.createNotificationChannel(rep);
    }

    private PendingIntent openIntent() {
        Intent i = new Intent(this, MainActivity.class);
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private Notification runNotification(String title, String text) {
        Intent stop = new Intent(this, GameService.class).setAction(ACT_STOP);
        PendingIntent sp = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CH_RUN)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(openIntent())
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(R.drawable.ic_stat, "Matikan", sp).build())
                .build();
    }

    private void updateRun(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NID_RUN, runNotification(getString(R.string.app_name), text));
    }

    private void postReport(String name, long dur, int avg, int low, int tmax, int drop) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        long min = dur / 60;
        String t = name + " • " + (min > 0 ? min + " mnt" : dur + " dtk");
        String body = (avg > 0 ? "Rata-rata " + avg + " FPS" : "FPS tidak terbaca")
                + (low > 0 ? ", terendah 1% " + low : "")
                + (tmax > 0 ? ", suhu maks " + tmax + "°" : "")
                + (drop > 0 ? ", baterai -" + drop + "%" : "");
        Notification n = new Notification.Builder(this, CH_REP)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(t)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(openIntent())
                .setAutoCancel(true)
                .build();
        nm.notify(NID_REP, n);
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (overlay != null) overlay.rebuild();
    }
}
