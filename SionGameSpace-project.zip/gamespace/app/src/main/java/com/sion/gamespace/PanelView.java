package com.sion.gamespace;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Panel samping: kartu kaca melayang berisi HUD, mode, dan ubin cepat. */
final class PanelView extends FrameLayout {
    private final Overlay.Host host;
    private final boolean right;
    private final int margin;
    private final FrameLayout card;
    private final LinearLayout content;
    private final TextView title;
    private final TextView gameName;
    private final TextView fpsBig;
    private final TextView sTemp, sPing, sBat, sCpu;
    private final GraphView graph;
    private final ModeBar modes;
    private final List<TileView> tiles = new ArrayList<TileView>();
    private final List<View> stagger = new ArrayList<View>();
    private int shownFps;
    private ValueAnimator fpsAnim;
    private float panelPx;

    PanelView(Context c, Overlay.Host host, boolean right, int panelWidthPx) {
        super(c);
        this.host = host;
        this.right = right;
        this.panelPx = panelWidthPx;
        margin = Ui.dp(c, 10);
        setClipChildren(false);

        card = new FrameLayout(c);
        card.setBackground(Ui.glassRadii(c, 26, !right));
        if (android.os.Build.VERSION.SDK_INT >= 21) card.setElevation(Ui.dp(c, 18));
        LayoutParams cp = new LayoutParams(panelWidthPx - margin * 2, ViewGroup.LayoutParams.MATCH_PARENT);
        cp.gravity = right ? Gravity.RIGHT : Gravity.LEFT;
        cp.setMargins(margin, margin * 2, margin, margin * 2);
        addView(card, cp);

        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        card.addView(sv, new LayoutParams(-1, -1));

        content = new LinearLayout(c);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(c, 14);
        content.setPadding(pad, pad, pad, pad);
        sv.addView(content, new ViewGroup.LayoutParams(-1, -2));

        // judul
        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        View dot = new View(c);
        dot.setBackground(Ui.pill(c, Ui.CYAN, 0x00000000));
        head.addView(dot, new LinearLayout.LayoutParams(Ui.dp(c, 8), Ui.dp(c, 8)));
        LinearLayout tcol = new LinearLayout(c);
        tcol.setOrientation(LinearLayout.VERTICAL);
        title = text(c, "Sion Game Space", 15, Ui.TEXT, true);
        gameName = text(c, "", 11, Ui.MUTE, false);
        gameName.setSingleLine(true);
        gameName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        tcol.addView(title);
        tcol.addView(gameName);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, -2, 1f);
        tp.leftMargin = Ui.dp(c, 10);
        head.addView(tcol, tp);
        TextView close = text(c, "Tutup", 11, Ui.SKY, true);
        close.setPadding(Ui.dp(c, 10), Ui.dp(c, 6), Ui.dp(c, 10), Ui.dp(c, 6));
        close.setBackground(Ui.pill(c, 0x1FFFFFFF, 0x22FFFFFF));
        close.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { PanelView.this.host.closePanel(); }
        });
        head.addView(close);
        content.addView(head);
        stagger.add(head);

        // kartu HUD
        LinearLayout hud = new LinearLayout(c);
        hud.setOrientation(LinearLayout.VERTICAL);
        hud.setBackground(Ui.inner(c, 18));
        hud.setPadding(Ui.dp(c, 12), Ui.dp(c, 10), Ui.dp(c, 12), Ui.dp(c, 10));
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.BOTTOM);
        fpsBig = text(c, "--", 40, Ui.TEXT, true);
        fpsBig.setTypeface(Typeface.create("sans-serif-light", Typeface.BOLD));
        TextView fl = text(c, "FPS", 12, Ui.CYAN, true);
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-2, -2);
        flp.leftMargin = Ui.dp(c, 6);
        flp.bottomMargin = Ui.dp(c, 8);
        row.addView(fpsBig);
        row.addView(fl, flp);
        hud.addView(row);
        graph = new GraphView(c);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, Ui.dp(c, 52));
        gp.topMargin = Ui.dp(c, 2);
        hud.addView(graph, gp);
        LinearLayout stats = new LinearLayout(c);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        sTemp = stat(c, stats, "Suhu");
        sPing = stat(c, stats, "Ping");
        sBat = stat(c, stats, "Baterai");
        sCpu = stat(c, stats, "CPU");
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = Ui.dp(c, 8);
        hud.addView(stats, sp);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = Ui.dp(c, 12);
        content.addView(hud, hp);
        stagger.add(hud);

        // mode
        TextView ml = text(c, "Mode performa", 12, Ui.MUTE, true);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(-2, -2);
        mlp.topMargin = Ui.dp(c, 14);
        mlp.bottomMargin = Ui.dp(c, 6);
        content.addView(ml, mlp);
        stagger.add(ml);
        modes = new ModeBar(c);
        modes.setListener(new ModeBar.Listener() {
            @Override public void onMode(String id) { PanelView.this.host.setMode(id); }
        });
        content.addView(modes, new LinearLayout.LayoutParams(-1, Ui.dp(c, 40)));
        stagger.add(modes);

        // ubin
        TextView tl = text(c, "Aksi cepat", 12, Ui.MUTE, true);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-2, -2);
        tlp.topMargin = Ui.dp(c, 14);
        tlp.bottomMargin = Ui.dp(c, 6);
        content.addView(tl, tlp);
        stagger.add(tl);
        String[][] defs = {
                {"focus", "Fokus"}, {"ram", "RAM"}, {"shot", "Foto"}, {"rec", "Rekam"},
                {"refresh", "Layar"}, {"wifi", "Wi-Fi"}, {"bright", "Terang"}, {"settings", "Atur"}};
        int[] icons = {TileView.FOCUS, TileView.RAM, TileView.SHOT, TileView.REC,
                TileView.REFRESH, TileView.WIFI, TileView.BRIGHT, TileView.GEAR};
        for (int rI = 0; rI < 2; rI++) {
            LinearLayout tr = new LinearLayout(c);
            tr.setOrientation(LinearLayout.HORIZONTAL);
            for (int k = 0; k < 4; k++) {
                int i = rI * 4 + k;
                TileView t = new TileView(c, defs[i][0], icons[i], defs[i][1]);
                t.setOnTile(new TileView.Click() {
                    @Override public void onClick(TileView tv) { PanelView.this.host.tile(tv.id); refreshTiles(); }
                });
                tiles.add(t);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(c, 76), 1f);
                if (k > 0) lp.leftMargin = Ui.dp(c, 7);
                tr.addView(t, lp);
            }
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            if (rI > 0) rp.topMargin = Ui.dp(c, 7);
            content.addView(tr, rp);
            stagger.add(tr);
        }

        TextView open = text(c, "Buka Sion Game Space", 12, Ui.SKY, true);
        open.setGravity(Gravity.CENTER);
        open.setPadding(0, Ui.dp(c, 12), 0, Ui.dp(c, 4));
        open.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { PanelView.this.host.openApp(); }
        });
        content.addView(open, new LinearLayout.LayoutParams(-1, -2));
        stagger.add(open);
    }

    private TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView stat(Context c, LinearLayout parent, String label) {
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView v = text(c, "--", 13, Ui.TEXT, true);
        TextView l = text(c, label, 10, Ui.MUTE, false);
        col.addView(v);
        col.addView(l);
        parent.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        return v;
    }

    void setGame(String name) {
        gameName.setText(name == null || name.length() == 0 ? "Mode panel" : name);
    }

    void refreshTiles() {
        for (TileView t : tiles) {
            if ("settings".equals(t.id)) continue;
            t.setOn(host.tileOn(t.id), true);
            String s = host.tileSub(t.id);
            if (s != null) t.setSub(s);
        }
        modes.select(host.activeMode(), true);
    }

    void syncNow() {
        for (TileView t : tiles) {
            if ("settings".equals(t.id)) continue;
            t.setOn(host.tileOn(t.id), false);
            String s = host.tileSub(t.id);
            if (s != null) t.setSub(s);
        }
        modes.select(host.activeMode(), false);
    }

    TileView tile(String id) {
        for (TileView t : tiles) if (t.id.equals(id)) return t;
        return null;
    }

    void bind(Metrics m, boolean good) {
        if (m == null) return;
        animateFps(m.fps);
        graph.setData(m.ft);
        sTemp.setText(m.temp() > 0 ? m.temp() + "°" : "--");
        sTemp.setTextColor(m.temp() >= 46 ? Ui.WARN : Ui.TEXT);
        sPing.setText(m.ping >= 0 ? m.ping + " ms" : "--");
        sBat.setText(m.bat >= 0 ? m.bat + "%" : "--");
        sCpu.setText(m.cpuLoad >= 0 ? Math.round(m.cpuLoad) + "%" : "--");
    }

    private void animateFps(int to) {
        if (to <= 0) { fpsBig.setText("--"); shownFps = 0; return; }
        if (fpsAnim != null) fpsAnim.cancel();
        fpsAnim = ValueAnimator.ofInt(shownFps, to);
        fpsAnim.setDuration(420);
        fpsAnim.setInterpolator(new DecelerateInterpolator());
        fpsAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                shownFps = (Integer) a.getAnimatedValue();
                fpsBig.setText(String.valueOf(shownFps));
            }
        });
        fpsAnim.start();
    }

    /** Geser panel mengikuti jari. p=0 tersembunyi, p=1 terbuka penuh. */
    void reveal(float p) {
        float dist = panelPx;
        setTranslationX((right ? 1 : -1) * (1f - p) * dist);
        setAlpha(0.25f + 0.75f * p);
    }

    /** Animasi masuk berurutan untuk isi kartu. */
    void animateIn() {
        int i = 0;
        for (View v : stagger) {
            v.setAlpha(0f);
            v.setTranslationX((right ? 1 : -1) * Ui.dp(getContext(), 22));
            v.animate().alpha(1f).translationX(0f).setStartDelay(60L + i * 38L).setDuration(340)
                    .setInterpolator(new DecelerateInterpolator(1.8f)).start();
            i++;
        }
    }

    void cancelAnims() {
        if (fpsAnim != null) fpsAnim.cancel();
        for (View v : stagger) v.animate().cancel();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        // sentuhan di area margin di luar kartu menutup panel
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            host.closePanel();
        }
        return true;
    }
}
