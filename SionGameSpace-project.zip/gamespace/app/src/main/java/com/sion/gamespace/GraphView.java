package com.sion.gamespace;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.view.View;

/** Grafik waktu per frame (ms). Makin rendah dan rata makin mulus. */
final class GraphView extends View {
    private float[] data = new float[0];
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint guide = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Path area = new Path();

    GraphView(Context c) {
        super(c);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(Ui.dp(c, 1.6f));
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setColor(Ui.CYAN);
        fill.setStyle(Paint.Style.FILL);
        guide.setStyle(Paint.Style.STROKE);
        guide.setStrokeWidth(Ui.dp(c, 1));
        guide.setColor(0x33FFFFFF);
        guide.setPathEffect(new android.graphics.DashPathEffect(new float[]{Ui.dp(c, 3), Ui.dp(c, 4)}, 0));
    }

    void setData(float[] d) {
        data = d == null ? new float[0] : d;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        fill.setShader(new LinearGradient(0, 0, 0, h, 0x663EA6FF, 0x003EA6FF, Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        float max = 25f;
        for (float v : data) if (v > max) max = v;
        max *= 1.1f;
        float gy = h - (16.7f / max) * (h - 4);
        canvas.drawLine(0, gy, w, gy, guide);
        int n = data.length;
        if (n < 2) return;
        path.reset();
        area.reset();
        float step = w / (float) (n - 1);
        for (int i = 0; i < n; i++) {
            float x = i * step;
            float y = h - 2 - Math.min(1f, data[i] / max) * (h - 4);
            if (i == 0) {
                path.moveTo(x, y);
                area.moveTo(x, h);
                area.lineTo(x, y);
            } else {
                path.lineTo(x, y);
                area.lineTo(x, y);
            }
        }
        area.lineTo(w, h);
        area.close();
        canvas.drawPath(area, fill);
        canvas.drawPath(path, line);
    }
}
