package com.sion.gamespace;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/** Ubin aksi cepat: ikon gambar kanvas, isi menyala saat aktif, menciut saat ditekan. */
final class TileView extends View {
    static final int FOCUS = 0, RAM = 1, SHOT = 2, REC = 3, REFRESH = 4, WIFI = 5, BRIGHT = 6, GEAR = 7;

    interface Click { void onClick(TileView t); }

    final String id;
    private final int icon;
    private String label;
    private String sub = "";
    private boolean on;
    private boolean busy;
    private float fill;      // 0..1 animasi aktif
    private float press;     // 0..1
    private float spin;      // putaran saat sibuk
    private Click click;
    private ValueAnimator fillAnim;
    private ValueAnimator spinAnim;
    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ink = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint small = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path p = new Path();

    TileView(Context c, String id, int icon, String label) {
        super(c);
        this.id = id;
        this.icon = icon;
        this.label = label;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Ui.dp(c, 1));
        ink.setStyle(Paint.Style.STROKE);
        ink.setStrokeWidth(Ui.dp(c, 2));
        ink.setStrokeCap(Paint.Cap.ROUND);
        ink.setStrokeJoin(Paint.Join.ROUND);
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setTextSize(Ui.dp(c, 11));
        txt.setFakeBoldText(true);
        small.setTextAlign(Paint.Align.CENTER);
        small.setTextSize(Ui.dp(c, 9.5f));
        setClickable(true);
    }

    void setOnTile(Click c) { click = c; }

    void setLabel(String l) { label = l; invalidate(); }

    void setSub(String s) { sub = s == null ? "" : s; invalidate(); }

    boolean isOn() { return on; }

    void setOn(boolean v, boolean animate) {
        if (on == v && fillAnim == null) { if (!animate) { fill = v ? 1 : 0; invalidate(); } return; }
        on = v;
        if (fillAnim != null) fillAnim.cancel();
        if (!animate) { fill = v ? 1 : 0; invalidate(); return; }
        fillAnim = ValueAnimator.ofFloat(fill, v ? 1f : 0f);
        fillAnim.setDuration(320);
        fillAnim.setInterpolator(new DecelerateInterpolator(1.6f));
        fillAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) { fill = (Float) a.getAnimatedValue(); invalidate(); }
        });
        fillAnim.start();
    }

    void setBusy(boolean b) {
        if (busy == b) return;
        busy = b;
        if (b) {
            spinAnim = ValueAnimator.ofFloat(0f, 360f);
            spinAnim.setDuration(900);
            spinAnim.setRepeatCount(ValueAnimator.INFINITE);
            spinAnim.setInterpolator(new android.view.animation.LinearInterpolator());
            spinAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator a) { spin = (Float) a.getAnimatedValue(); invalidate(); }
            });
            spinAnim.start();
        } else {
            if (spinAnim != null) spinAnim.cancel();
            spin = 0;
            invalidate();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (spinAnim != null) spinAnim.cancel();
        if (fillAnim != null) fillAnim.cancel();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                animPress(1f);
                return true;
            case MotionEvent.ACTION_UP:
                animPress(0f);
                if (e.getX() >= 0 && e.getX() <= getWidth() && e.getY() >= 0 && e.getY() <= getHeight()) {
                    performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
                    if (click != null) click.onClick(this);
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                animPress(0f);
                return true;
            default:
                return true;
        }
    }

    private void animPress(float to) {
        ValueAnimator a = ValueAnimator.ofFloat(press, to);
        a.setDuration(to > 0 ? 90 : 220);
        a.setInterpolator(to > 0 ? new DecelerateInterpolator() : new android.view.animation.OvershootInterpolator(2f));
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator x) { press = (Float) x.getAnimatedValue(); invalidate(); }
        });
        a.start();
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth();
        int h = getHeight();
        float sc = 1f - 0.07f * press;
        c.save();
        c.scale(sc, sc, w / 2f, h / 2f);
        float rad = Ui.dp(getContext(), 16);
        r.set(1, 1, w - 1, h - 1);
        // dasar kaca
        bg.setColor(0x1FFFFFFF);
        c.drawRoundRect(r, rad, rad, bg);
        // isi biru menyala
        if (fill > 0.001f) {
            bg.setShader(new android.graphics.LinearGradient(0, 0, w, h,
                    alpha(0x2459FF, fill), alpha(0x3EA6FF, fill), android.graphics.Shader.TileMode.CLAMP));
            c.drawRoundRect(r, rad, rad, bg);
            bg.setShader(null);
        }
        stroke.setColor(on ? 0xAAB4DCFF : 0x30FFFFFF);
        c.drawRoundRect(r, rad, rad, stroke);

        float cx = w / 2f;
        float cy = h * 0.38f;
        float s = Ui.dp(getContext(), 9);
        ink.setColor(on ? 0xFFFFFFFF : 0xFFD6E6FF);
        ink.setStyle(Paint.Style.STROKE);
        c.save();
        if (busy) c.rotate(spin, cx, cy);
        drawIcon(c, cx, cy, s);
        c.restore();

        txt.setColor(on ? 0xFFFFFFFF : Ui.TEXT);
        c.drawText(label, cx, h * 0.72f, txt);
        small.setColor(on ? 0xCCFFFFFF : Ui.MUTE);
        if (sub.length() > 0) c.drawText(sub, cx, h * 0.89f, small);
        c.restore();
    }

    private static int alpha(int rgb, float t) {
        return (((int) (255 * Math.max(0f, Math.min(1f, t)))) << 24) | (rgb & 0xFFFFFF);
    }

    private void drawIcon(Canvas c, float x, float y, float s) {
        p.reset();
        switch (icon) {
            case FOCUS: { // target
                c.drawCircle(x, y, s, ink);
                c.drawCircle(x, y, s * 0.45f, ink);
                c.drawLine(x, y - s * 1.35f, x, y - s * 0.75f, ink);
                c.drawLine(x, y + s * 0.75f, x, y + s * 1.35f, ink);
                c.drawLine(x - s * 1.35f, y, x - s * 0.75f, y, ink);
                c.drawLine(x + s * 0.75f, y, x + s * 1.35f, y, ink);
                break;
            }
            case RAM: { // chip
                r.set(x - s * 0.8f, y - s * 0.8f, x + s * 0.8f, y + s * 0.8f);
                c.drawRoundRect(r, s * 0.25f, s * 0.25f, ink);
                for (int i = -1; i <= 1; i += 2) {
                    for (int k = -1; k <= 1; k += 2) {
                        c.drawLine(x + k * s * 0.35f, y + i * s * 0.8f, x + k * s * 0.35f, y + i * s * 1.25f, ink);
                        c.drawLine(x + i * s * 0.8f, y + k * s * 0.35f, x + i * s * 1.25f, y + k * s * 0.35f, ink);
                    }
                }
                break;
            }
            case SHOT: { // kamera
                r.set(x - s * 1.2f, y - s * 0.8f, x + s * 1.2f, y + s * 0.95f);
                c.drawRoundRect(r, s * 0.3f, s * 0.3f, ink);
                c.drawCircle(x, y + s * 0.1f, s * 0.45f, ink);
                c.drawLine(x - s * 0.5f, y - s * 0.8f, x - s * 0.25f, y - s * 1.15f, ink);
                c.drawLine(x - s * 0.25f, y - s * 1.15f, x + s * 0.25f, y - s * 1.15f, ink);
                c.drawLine(x + s * 0.25f, y - s * 1.15f, x + s * 0.5f, y - s * 0.8f, ink);
                break;
            }
            case REC: { // rekam
                c.drawCircle(x, y, s, ink);
                Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
                f.setColor(on ? 0xFFFF5470 : 0xFFFF7A90);
                c.drawCircle(x, y, s * 0.5f, f);
                break;
            }
            case REFRESH: { // layar + gelombang
                r.set(x - s * 1.15f, y - s * 0.8f, x + s * 1.15f, y + s * 0.8f);
                c.drawRoundRect(r, s * 0.3f, s * 0.3f, ink);
                p.moveTo(x - s * 0.7f, y + s * 0.15f);
                p.lineTo(x - s * 0.3f, y + s * 0.15f);
                p.lineTo(x - s * 0.1f, y - s * 0.4f);
                p.lineTo(x + s * 0.2f, y + s * 0.4f);
                p.lineTo(x + s * 0.4f, y + s * 0.15f);
                p.lineTo(x + s * 0.7f, y + s * 0.15f);
                c.drawPath(p, ink);
                break;
            }
            case WIFI: {
                r.set(x - s * 1.2f, y - s * 0.9f, x + s * 1.2f, y + s * 1.5f);
                c.drawArc(r, 220, 100, false, ink);
                r.set(x - s * 0.8f, y - s * 0.4f, x + s * 0.8f, y + s * 1.1f);
                c.drawArc(r, 220, 100, false, ink);
                Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
                f.setColor(ink.getColor());
                c.drawCircle(x, y + s * 0.65f, s * 0.2f, f);
                break;
            }
            case BRIGHT: { // matahari
                c.drawCircle(x, y, s * 0.5f, ink);
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI / 4 * i;
                    c.drawLine((float) (x + Math.cos(a) * s * 0.85f), (float) (y + Math.sin(a) * s * 0.85f),
                            (float) (x + Math.cos(a) * s * 1.2f), (float) (y + Math.sin(a) * s * 1.2f), ink);
                }
                break;
            }
            default: { // gerigi
                c.drawCircle(x, y, s * 0.4f, ink);
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI / 4 * i;
                    c.drawLine((float) (x + Math.cos(a) * s * 0.75f), (float) (y + Math.sin(a) * s * 0.75f),
                            (float) (x + Math.cos(a) * s * 1.15f), (float) (y + Math.sin(a) * s * 1.15f), ink);
                }
                c.drawCircle(x, y, s * 0.8f, ink);
                break;
            }
        }
    }
}
