package com.sion.gamespace;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Semua jendela melayang: gagang tepi, panel geser, HUD, dan toast. Hanya dipakai dari thread utama. */
final class Overlay {
    interface Host {
        void setMode(String id);
        void tile(String id);
        boolean tileOn(String id);
        String tileSub(String id);
        String activeMode();
        void openApp();
        void closePanel();
        void onPanelState(boolean open);
    }

    private final Context ctx;
    private final Host host;
    private final Store store;
    private final WindowManager wm;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final List<EdgeHandleView> handles = new ArrayList<EdgeHandleView>();
    private PanelView panel;
    private WindowManager.LayoutParams panelLp;
    private boolean panelRight;
    private boolean panelOpen;
    private boolean panelAdded;
    private float lastDim = -1f;
    private ValueAnimator slide;
    private TextView hud;
    private TextView toastView;
    private boolean handlesShown;
    private boolean previewMode;
    private String gameLabel = "";
    private volatile boolean busy;
    private Metrics last;
    private final Random rnd = new Random();

    Overlay(Context c, Host h, Store s) {
        ctx = c.getApplicationContext();
        host = h;
        store = s;
        wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
    }

    boolean isBusy() { return busy; }

    boolean isPanelOpen() { return panelOpen; }

    boolean canDraw() {
        return Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(ctx);
    }

    // ---------------------------------------------------------------- ukuran layar

    private int[] screen() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return new int[]{dm.widthPixels, dm.heightPixels};
    }

    private int panelWidth() {
        int[] s = screen();
        int w = Math.min(Ui.dp(ctx, 304), (int) (Math.min(s[0], s[1]) * 0.80f));
        if (s[0] > s[1]) w = Math.min(Ui.dp(ctx, 304), (int) (s[0] * 0.42f));
        return w;
    }

    private WindowManager.LayoutParams baseParams(int w, int h, int flags) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT);
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return lp;
    }

    private static final int NF = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
    private static final int NTM = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
    private static final int NT = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
    private static final int LNL = WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
    private static final int LIS = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;

    // ---------------------------------------------------------------- gagang

    void showHandles(String label) {
        gameLabel = label == null ? "" : label;
        ui.post(new Runnable() { @Override public void run() { doShowHandles(); } });
    }

    void hideAll() {
        ui.post(new Runnable() {
            @Override public void run() {
                previewMode = false;
                removePanelNow();
                doHideHandles();
                removeHud();
                removeToast();
            }
        });
    }

    void rebuild() {
        ui.post(new Runnable() {
            @Override public void run() {
                boolean was = handlesShown;
                boolean open = panelOpen;
                removePanelNow();
                doHideHandles();
                removeHud();
                if (was) doShowHandles();
                if (open) openPanel(panelRight, true);
            }
        });
    }

    private void doShowHandles() {
        if (!canDraw()) return;
        doHideHandles();
        JSONObject cfg = store.cfg();
        String side = cfg.optString("side", "right");
        boolean edge = !"tab".equals(cfg.optString("edgeMode", "edge"));
        boolean stealth = cfg.optBoolean("stealth", false);
        int len = Ui.dp(ctx, (float) cfg.optDouble("handleLen", 150));
        float yPos = (float) cfg.optDouble("handleY", 0.38);
        int[] s = screen();
        int y = (int) (yPos * s[1] - len / 2f);
        y = Math.max(Ui.dp(ctx, 40), Math.min(s[1] - len - Ui.dp(ctx, 40), y));
        if ("both".equals(side)) {
            addHandle(true, edge, stealth, len, y);
            addHandle(false, edge, stealth, len, y);
        } else {
            addHandle("right".equals(side), edge, stealth, len, y);
        }
        handlesShown = true;
        updateHudWindow();
    }

    private void addHandle(final boolean right, boolean edge, boolean stealth, int len, int y) {
        int wpx = Ui.dp(ctx, edge ? 26 : 22);
        EdgeHandleView hv = new EdgeHandleView(ctx, right, stealth, panelWidth());
        WindowManager.LayoutParams lp = baseParams(wpx, len, NF | NTM | LNL | LIS);
        lp.gravity = Gravity.TOP | (right ? Gravity.RIGHT : Gravity.LEFT);
        lp.x = edge ? 0 : Ui.dp(ctx, 28);
        lp.y = y;
        hv.setListener(new EdgeHandleView.Listener() {
            @Override public void onDragStart() { beginDrag(right); }
            @Override public void onDrag(float p) { dragTo(p); }
            @Override public void onDragEnd(boolean open) { endDrag(open); }
            @Override public void onTap() { buzz(); openPanel(right, true); }
        });
        try {
            wm.addView(hv, lp);
            handles.add(hv);
        } catch (RuntimeException ignored) { }
    }

    private void doHideHandles() {
        for (EdgeHandleView h : handles) {
            try { wm.removeView(h); } catch (RuntimeException ignored) { }
        }
        handles.clear();
        handlesShown = false;
    }

    // ---------------------------------------------------------------- panel

    private void ensurePanel(boolean right) {
        if (panelAdded) return;
        panelRight = right;
        panel = new PanelView(ctx, new Host() {
            @Override public void setMode(String id) { host.setMode(id); }
            @Override public void tile(String id) { host.tile(id); }
            @Override public boolean tileOn(String id) { return host.tileOn(id); }
            @Override public String tileSub(String id) { return host.tileSub(id); }
            @Override public String activeMode() { return host.activeMode(); }
            @Override public void openApp() { host.openApp(); }
            @Override public void closePanel() { Overlay.this.closePanel(); }
            @Override public void onPanelState(boolean open) { }
        }, right, panelWidth());
        panel.setGame(gameLabel);
        panel.syncNow();
        int flags = NF | LNL | LIS | NT | WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        int[] s = screen();
        panelLp = baseParams(s[0], s[1], flags);
        panelLp.gravity = Gravity.TOP | Gravity.LEFT;
        panelLp.dimAmount = 0f;
        if (Build.VERSION.SDK_INT >= 31) {
            panelLp.flags |= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
            panelLp.setBlurBehindRadius(0);
        }
        panel.reveal(0f);
        try {
            wm.addView(panel, panelLp);
            panelAdded = true;
        } catch (RuntimeException e) {
            panel = null;
            panelAdded = false;
        }
        busy = panelAdded;
        lastDim = 0f;
    }

    private void beginDrag(boolean right) {
        if (slide != null) slide.cancel();
        ensurePanel(right);
    }

    private void dragTo(float p) {
        if (!panelAdded) return;
        panel.reveal(p);
        applyDim(p);
    }

    private void applyDim(float p) {
        if (Math.abs(p - lastDim) < 0.02f && p > 0.01f && p < 0.99f) return;
        lastDim = p;
        panelLp.dimAmount = 0.55f * p;
        if (Build.VERSION.SDK_INT >= 31) panelLp.setBlurBehindRadius((int) (24 * p));
        try { wm.updateViewLayout(panel, panelLp); } catch (RuntimeException ignored) { }
    }

    private void endDrag(boolean open) {
        if (!panelAdded) return;
        if (open) buzz();
        animateTo(open ? 1f : 0f, open);
    }

    void openPanel(boolean right, boolean fromTap) {
        if (panelOpen) return;
        if (slide != null) slide.cancel();
        ensurePanel(right);
        if (!panelAdded) return;
        panel.reveal(0f);
        animateTo(1f, true);
    }

    void closePanel() {
        ui.post(new Runnable() {
            @Override public void run() {
                if (!panelAdded) return;
                if (slide != null) slide.cancel();
                animateTo(0f, false);
            }
        });
    }

    private void animateTo(final float target, final boolean open) {
        if (slide != null) slide.cancel();
        float from = panel == null ? 0f : (panelOpen ? 1f : Math.max(0f, Math.min(1f, currentReveal())));
        slide = ValueAnimator.ofFloat(from, target);
        slide.setDuration(open ? 420 : 260);
        slide.setInterpolator(open ? new OvershootInterpolator(0.8f) : new DecelerateInterpolator());
        slide.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                if (panel == null) return;
                float v = (Float) a.getAnimatedValue();
                panel.reveal(Math.min(1f, v));
                applyDim(Math.max(0f, Math.min(1f, v)));
            }
        });
        slide.addListener(new AnimatorListenerAdapter() {
            boolean cancelled;
            @Override public void onAnimationCancel(Animator a) { cancelled = true; }
            @Override public void onAnimationEnd(Animator a) {
                if (cancelled || panel == null) return;
                if (open) {
                    panelOpen = true;
                    panelLp.flags &= ~NT;
                    try { wm.updateViewLayout(panel, panelLp); } catch (RuntimeException ignored) { }
                    panel.reveal(1f);
                    panel.animateIn();
                    if (last != null) panel.bind(last, true);
                    host.onPanelState(true);
                } else {
                    removePanelNow();
                    host.onPanelState(false);
                    if (previewMode) { previewMode = false; if (gameLabel.length() == 0) doHideHandles(); }
                }
            }
        });
        slide.start();
    }

    private float currentReveal() {
        if (panel == null) return 0f;
        float dist = panelWidth();
        float tx = Math.abs(panel.getTranslationX());
        return 1f - (tx / dist);
    }

    private void removePanelNow() {
        if (slide != null) { slide.cancel(); slide = null; }
        if (panel != null) {
            panel.cancelAnims();
            try { wm.removeView(panel); } catch (RuntimeException ignored) { }
        }
        panel = null;
        panelAdded = false;
        panelOpen = false;
        busy = false;
        lastDim = -1f;
    }

    void setGameLabel(final String label) {
        gameLabel = label == null ? "" : label;
        ui.post(new Runnable() { @Override public void run() { if (panel != null) panel.setGame(gameLabel); } });
    }

    void refreshPanel() {
        ui.post(new Runnable() { @Override public void run() { if (panel != null) panel.refreshTiles(); } });
    }

    void setBusyTile(final String id, final boolean b) {
        ui.post(new Runnable() {
            @Override public void run() {
                if (panel == null) return;
                TileView t = panel.tile(id);
                if (t != null) t.setBusy(b);
            }
        });
    }

    // ---------------------------------------------------------------- data

    void bind(final Metrics m) {
        last = m;
        ui.post(new Runnable() {
            @Override public void run() {
                if (panel != null && panelOpen) panel.bind(m, true);
                updateHudText(m);
            }
        });
    }

    // ---------------------------------------------------------------- HUD

    private void updateHudWindow() {
        JSONObject cfg = store.cfg();
        if (!cfg.optBoolean("hud", true) || !handlesShown || !canDraw()) { removeHud(); return; }
        if (hud != null) return;
        hud = new TextView(ctx);
        hud.setTextColor(Ui.TEXT);
        hud.setTextSize(11f);
        hud.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        hud.setShadowLayer(3f, 0, 1f, 0xFF000000);
        hud.setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 5), Ui.dp(ctx, 10), Ui.dp(ctx, 5));
        hud.setBackground(Ui.pill(ctx, 0x99081022, 0x33BFDFFF));
        hud.setAlpha(Math.max(0.2f, Math.min(1f, cfg.optInt("hudOpacity", 85) / 100f)));
        int g;
        String c = cfg.optString("hudCorner", "tl");
        int[] gr = {Gravity.TOP | Gravity.LEFT};
        if ("tr".equals(c)) g = Gravity.TOP | Gravity.RIGHT;
        else if ("bl".equals(c)) g = Gravity.BOTTOM | Gravity.LEFT;
        else if ("br".equals(c)) g = Gravity.BOTTOM | Gravity.RIGHT;
        else g = gr[0];
        WindowManager.LayoutParams lp = baseParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT, NF | NT | NTM | LNL | LIS);
        lp.gravity = g;
        lp.x = Ui.dp(ctx, 14);
        lp.y = Ui.dp(ctx, 30);
        hud.setText("--");
        try { wm.addView(hud, lp); } catch (RuntimeException e) { hud = null; }
    }

    private void removeHud() {
        if (hud != null) {
            try { wm.removeView(hud); } catch (RuntimeException ignored) { }
            hud = null;
        }
    }

    private void updateHudText(Metrics m) {
        if (hud == null) return;
        JSONObject cfg = store.cfg();
        StringBuilder sb = new StringBuilder();
        if (cfg.optBoolean("hudFps", true)) sb.append(m.fps > 0 ? m.fps + " FPS" : "-- FPS");
        if (cfg.optBoolean("hudTemp", true) && m.temp() > 0) sb.append(sb.length() > 0 ? "  " : "").append(m.temp()).append("°C");
        if (cfg.optBoolean("hudPing", true) && m.ping >= 0) sb.append(sb.length() > 0 ? "  " : "").append(m.ping).append("ms");
        if (cfg.optBoolean("hudBat", false) && m.bat >= 0) sb.append(sb.length() > 0 ? "  " : "").append(m.bat).append("%");
        if (sb.length() == 0) sb.append("--");
        hud.setText(sb.toString());
    }

    void refreshHud() {
        ui.post(new Runnable() {
            @Override public void run() { removeHud(); updateHudWindow(); if (last != null) updateHudText(last); }
        });
    }

    // ---------------------------------------------------------------- toast

    void toast(final String msg) {
        ui.post(new Runnable() {
            @Override public void run() {
                if (!canDraw()) return;
                removeToast();
                final TextView t = new TextView(ctx);
                t.setText(msg);
                t.setTextColor(Ui.TEXT);
                t.setTextSize(13f);
                t.setTypeface(Typeface.DEFAULT_BOLD);
                t.setPadding(Ui.dp(ctx, 18), Ui.dp(ctx, 10), Ui.dp(ctx, 18), Ui.dp(ctx, 10));
                t.setBackground(Ui.glass(ctx, 30));
                WindowManager.LayoutParams lp = baseParams(WindowManager.LayoutParams.WRAP_CONTENT,
                        WindowManager.LayoutParams.WRAP_CONTENT, NF | NT | NTM | LNL | LIS);
                lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
                lp.y = Ui.dp(ctx, 54);
                t.setAlpha(0f);
                t.setTranslationY(-Ui.dp(ctx, 16));
                try { wm.addView(t, lp); } catch (RuntimeException e) { return; }
                toastView = t;
                t.animate().alpha(1f).translationY(0f).setDuration(260).setInterpolator(new DecelerateInterpolator()).start();
                ui.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (toastView != t) return;
                        t.animate().alpha(0f).translationY(-Ui.dp(ctx, 10)).setDuration(240)
                                .withEndAction(new Runnable() { @Override public void run() { if (toastView == t) removeToast(); } }).start();
                    }
                }, 1700);
            }
        });
    }

    private void removeToast() {
        if (toastView != null) {
            try { wm.removeView(toastView); } catch (RuntimeException ignored) { }
            toastView = null;
        }
    }

    // ---------------------------------------------------------------- pratinjau

    /** Tampilkan gagang dan panel dengan data palsu untuk mencoba tampilan dari aplikasi. */
    void preview() {
        ui.post(new Runnable() {
            @Override public void run() {
                if (!canDraw()) return;
                previewMode = true;
                if (!handlesShown) doShowHandles();
                ui.postDelayed(new Runnable() { @Override public void run() { openPanel(right(), true); } }, 350);
                feedFake();
            }
        });
    }

    private boolean right() {
        return !"left".equals(store.cfg().optString("side", "right"));
    }

    private void feedFake() {
        if (!previewMode) return;
        Metrics m = new Metrics();
        m.fps = 56 + rnd.nextInt(5);
        m.tempCpu = 40 + rnd.nextInt(3);
        m.bat = 76;
        m.ping = 20 + rnd.nextInt(12);
        m.cpuLoad = 28 + rnd.nextInt(14);
        float[] ft = new float[40];
        for (int i = 0; i < ft.length; i++) ft[i] = 15.5f + rnd.nextFloat() * 3f + (i % 17 == 0 ? 6f : 0f);
        m.ft = ft;
        bind(m);
        ui.postDelayed(new Runnable() { @Override public void run() { feedFake(); } }, 700);
    }

    // ---------------------------------------------------------------- getar

    private void buzz() {
        if (!store.cfg().optBoolean("haptic", true)) return;
        try {
            Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(14, 90));
            else v.vibrate(14);
        } catch (RuntimeException ignored) { }
    }
}
