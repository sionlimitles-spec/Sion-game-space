package com.sion.gamespace;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.OvershootInterpolator;

/** Pemilih 4 mode dengan sorot yang meluncur. */
final class ModeBar extends View {
    interface Listener { void onMode(String id); }

    static final String[] IDS = {"chill", "balance", "turbo", "tourney"};
    private static final String[] NAMES = {"Santai", "Seimbang", "Ngebut", "Turnamen"};

    private int index = 2;
    private float pos = 2f;
    private Listener listener;
    private ValueAnimator anim;
    private final Paint back = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hi = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();

    ModeBar(Context c) {
        super(c);
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setTextSize(Ui.dp(c, 11));
        txt.setFakeBoldText(true);
        setClickable(true);
    }

    void setListener(Listener l) { listener = l; }

    String current() { return IDS[index]; }

    void select(String id, boolean animate) {
        int i = 2;
        for (int k = 0; k < IDS.length; k++) if (IDS[k].equals(id)) i = k;
        index = i;
        if (anim != null) anim.cancel();
        if (!animate) { pos = i; invalidate(); return; }
        anim = ValueAnimator.ofFloat(pos, i);
        anim.setDuration(380);
        anim.setInterpolator(new OvershootInterpolator(1.1f));
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) { pos = (Float) a.getAnimatedValue(); invalidate(); }
        });
        anim.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_UP) {
            int i = Math.max(0, Math.min(3, (int) (e.getX() / (getWidth() / 4f))));
            if (i != index) {
                select(IDS[i], true);
                performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK);
                if (listener != null) listener.onMode(IDS[i]);
            }
        }
        return true;
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth();
        int h = getHeight();
        float rad = h / 2f;
        r.set(0, 0, w, h);
        back.setColor(0x24FFFFFF);
        c.drawRoundRect(r, rad, rad, back);
        float seg = w / 4f;
        float pad = Ui.dp(getContext(), 3);
        r.set(pos * seg + pad, pad, (pos + 1) * seg - pad, h - pad);
        hi.setShader(new LinearGradient(r.left, 0, r.right, 0, Ui.BLUE, Ui.SKY, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, hi);
        for (int i = 0; i < 4; i++) {
            float near = Math.max(0f, 1f - Math.abs(pos - i));
            txt.setColor(blend(Ui.MUTE, 0xFFFFFFFF, near));
            c.drawText(NAMES[i], seg * i + seg / 2f, h / 2f + txt.getTextSize() * 0.35f, txt);
        }
    }

    private static int blend(int a, int b, float t) {
        int rr = (int) (((a >> 16) & 255) + ((((b >> 16) & 255) - ((a >> 16) & 255)) * t));
        int gg = (int) (((a >> 8) & 255) + ((((b >> 8) & 255) - ((a >> 8) & 255)) * t));
        int bl = (int) ((a & 255) + (((b & 255) - (a & 255)) * t));
        return 0xFF000000 | (rr << 16) | (gg << 8) | bl;
    }
}
