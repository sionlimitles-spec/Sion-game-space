(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  /* ---------- jembatan ke Android ---------- */
  var cbs = {}, seq = 0;
  window.__gs_cb = function (id, s) {
    var f = cbs[id]; delete cbs[id];
    if (!f) return;
    var o; try { o = JSON.parse(s); } catch (e) { o = { error: 'balasan rusak' }; }
    f(o);
  };
  function call(cmd, args) {
    return new Promise(function (res) {
      var id = 'c' + (++seq), done = false;
      cbs[id] = function (o) { done = true; res(o); };
      setTimeout(function () { if (!done) { delete cbs[id]; res({ error: 'waktu habis' }); } }, 25000);
      try { window.GS.api(cmd, JSON.stringify(args || {}), id); } catch (e) { done = true; res({ error: String(e) }); }
    });
  }

  /* ---------- keadaan ---------- */
  var S = { root: false, overlay: false, running: false, game: '', cfg: {}, games: {}, sdk: 0 };
  var sessions = [];
  var tab = 'game';
  var sheetOpen = false;
  var MODES = [
    ['chill', 'Santai', 'Hemat baterai dan suhu rendah. Cocok untuk game ringan.'],
    ['balance', 'Seimbang', 'Tidak mengubah performa. Hanya panel dan mode fokus yang aktif.'],
    ['turbo', 'Ngebut', 'Tenaga lebih untuk main sehari-hari. Layar dikunci ke laju tertinggi.'],
    ['tourney', 'Turnamen', 'Tenaga paling tinggi, Wi-Fi latensi rendah, RAM dibersihkan.']
  ];

  /* ---------- bantu ---------- */
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { } return null; }
  var actx;
  function sfx(kind) {
    if (store('snd') === '0') return;
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      var o = actx.createOscillator(), g = actx.createGain(), t = actx.currentTime;
      o.type = 'sine';
      o.frequency.setValueAtTime(kind === 'ok' ? 520 : 380, t);
      if (kind === 'ok') o.frequency.exponentialRampToValueAtTime(880, t + .12);
      g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(.07, t + .01); g.gain.exponentialRampToValueAtTime(.0001, t + .16);
      o.connect(g); g.connect(actx.destination); o.start(t); o.stop(t + .18);
    } catch (e) { }
  }
  var toastT;
  function toast(m) {
    var t = $('#toast'); t.textContent = m; t.classList.add('on');
    clearTimeout(toastT); toastT = setTimeout(function () { t.classList.remove('on'); }, 2200);
  }
  function ripple(e) {
    var b = e.target.closest && e.target.closest('.btn'); if (!b) return;
    var r = b.getBoundingClientRect(), d = Math.max(r.width, r.height), s = document.createElement('span');
    s.className = 'ripple'; s.style.cssText = 'width:' + d + 'px;height:' + d + 'px;left:' + (e.clientX - r.left - d / 2) + 'px;top:' + (e.clientY - r.top - d / 2) + 'px';
    b.appendChild(s); setTimeout(function () { s.remove(); }, 650);
  }
  document.addEventListener('pointerdown', ripple);
  function countUp(el, to, ms) {
    var t0 = performance.now(); ms = ms || 700;
    (function f(t) {
      var p = Math.min(1, (t - t0) / ms), e = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(to * e);
      if (p < 1) requestAnimationFrame(f);
    })(t0);
  }
  function dur(s) {
    s = Math.round(s);
    if (s >= 3600) return Math.floor(s / 3600) + 'j ' + Math.floor(s % 3600 / 60) + 'm';
    if (s >= 60) return Math.round(s / 60) + ' mnt';
    return s + ' dtk';
  }
  var DAY = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'], MON = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
  function dstr(ms) {
    var d = new Date(ms), z = function (n) { return n < 10 ? '0' + n : n; };
    return DAY[d.getDay()] + ', ' + d.getDate() + ' ' + MON[d.getMonth()] + ' ' + z(d.getHours()) + '.' + z(d.getMinutes());
  }

  /* ---------- ikon game ---------- */
  var icons = {};
  function iconInto(el, pkg, name) {
    el.textContent = '';
    if (icons[pkg]) { el.style.backgroundImage = 'url(' + icons[pkg] + ')'; return; }
    var c = store('ic:' + pkg);
    if (c) { icons[pkg] = c; el.style.backgroundImage = 'url(' + c + ')'; return; }
    el.textContent = (name || pkg).charAt(0).toUpperCase();
    call('icon', { pkg: pkg }).then(function (u) {
      if (typeof u === 'string' && u.indexOf('data:') === 0) {
        icons[pkg] = u; store('ic:' + pkg, u);
        el.textContent = ''; el.style.backgroundImage = 'url(' + u + ')';
      }
    });
  }

  /* ---------- komponen ---------- */
  function seg(opts, value, onChange, cls) {
    var el = document.createElement('div');
    el.className = 'seg ' + (cls || '');
    el.style.gridTemplateColumns = 'repeat(' + opts.length + ',1fr)';
    var hi = '<i class="hi" style="width:calc((100% - 8px)/' + opts.length + ')"></i>';
    el.innerHTML = hi + opts.map(function (o) { return '<button data-v="' + esc(o[0]) + '">' + esc(o[1]) + '</button>'; }).join('');
    var h = $('.hi', el), btns = $$('button', el);
    function set(v, quiet) {
      var i = 0; btns.forEach(function (b, k) { var on = b.dataset.v === String(v); b.classList.toggle('on', on); if (on) i = k; });
      h.style.transform = 'translateX(' + (i * 100) + '%)';
    }
    set(value);
    btns.forEach(function (b) {
      b.addEventListener('click', function () { sfx('tap'); set(b.dataset.v); onChange(b.dataset.v); });
    });
    el.set = set;
    return el;
  }
  function sw(on, onChange, label) {
    var b = document.createElement('button');
    b.className = 'sw'; b.setAttribute('role', 'switch'); b.setAttribute('aria-label', label || '');
    b.setAttribute('aria-checked', on ? 'true' : 'false'); b.innerHTML = '<i></i>';
    b.addEventListener('click', function () {
      var v = b.getAttribute('aria-checked') !== 'true';
      b.setAttribute('aria-checked', v ? 'true' : 'false'); sfx('tap'); onChange(v);
    });
    return b;
  }
  function opt(parent, title, sub, ctrl, stack) {
    var o = document.createElement('div'); o.className = 'opt';
    var r = document.createElement('div'); r.className = 'row';
    r.innerHTML = '<div class="grow"><b>' + esc(title) + '</b>' + (sub ? '<p>' + esc(sub) + '</p>' : '') + '</div>';
    if (ctrl && !stack) r.appendChild(ctrl);
    o.appendChild(r);
    if (ctrl && stack) o.appendChild(ctrl);
    parent.appendChild(o);
    return o;
  }
  function range(min, max, step, val, fmt, onSet) {
    var w = document.createElement('div');
    w.innerHTML = '<input type="range" class="range" min="' + min + '" max="' + max + '" step="' + step + '" value="' + val + '">';
    var i = $('input', w), v = document.createElement('span'); v.className = 'val'; v.textContent = fmt(val);
    i.addEventListener('input', function () { v.textContent = fmt(+i.value); });
    i.addEventListener('change', function () { onSet(+i.value); });
    w.valueEl = v;
    return { el: w, val: v };
  }
  function cfgSet(k, v) {
    S.cfg[k] = v;
    call('setCfg', { key: k, value: v });
  }
  function stepper(val, min, max, step, fmt, onSet) {
    var w = document.createElement('div'); w.className = 'stepper';
    w.innerHTML = '<button aria-label="Kurangi">&minus;</button><b></b><button aria-label="Tambah">+</button>';
    var b = $('b', w), v = val;
    function show() { b.textContent = fmt(v); }
    show();
    $$('button', w).forEach(function (x, i) {
      x.addEventListener('click', function () { v = Math.max(min, Math.min(max, v + (i ? step : -step))); show(); sfx('tap'); onSet(v); });
    });
    return w;
  }

  /* ---------- lembar bawah ---------- */
  function openSheet(html, after) {
    $('#sheetBody').innerHTML = html;
    $('#sheet').scrollTop = 0;
    $('#scrim').classList.add('on'); $('#sheet').classList.add('on'); sheetOpen = true;
    if (after) after($('#sheetBody'));
  }
  function closeSheet() {
    $('#scrim').classList.remove('on'); $('#sheet').classList.remove('on'); sheetOpen = false;
    $('#sheet').style.transform = '';
  }
  $('#scrim').addEventListener('click', closeSheet);
  (function () {
    var sh = $('#sheet'), y0 = null, dy = 0;
    sh.addEventListener('touchstart', function (e) { if (sh.scrollTop <= 0 && e.target.closest('.grab,.shead,h3')) { y0 = e.touches[0].clientY; dy = 0; sh.style.transition = 'none'; } }, { passive: true });
    sh.addEventListener('touchmove', function (e) { if (y0 === null) return; dy = Math.max(0, e.touches[0].clientY - y0); sh.style.transform = 'translateY(' + dy + 'px)'; }, { passive: true });
    sh.addEventListener('touchend', function () { if (y0 === null) return; sh.style.transition = ''; var c = dy > 110; y0 = null; if (c) closeSheet(); else sh.style.transform = ''; });
  })();

  /* ---------- status ---------- */
  function renderStatus() {
    var chip = $('#chip'), live = S.running && S.game;
    var g = live && S.games[S.game];
    var cls = 'chip', txt;
    if (!S.root) { cls += ' bad'; txt = 'Butuh root'; }
    else if (!S.overlay) { cls += ' warn'; txt = 'Izin kurang'; }
    else if (live) { cls += ' play'; txt = 'Main: ' + (g ? g.name : ''); }
    else if (S.running) { cls += ' ok'; txt = 'Siaga'; }
    else txt = 'Mati';
    chip.className = cls; $('span', chip).textContent = txt;
    var s = $('#swService');
    s.setAttribute('aria-checked', S.running ? 'true' : 'false');
    $('#powerSub').textContent = S.running ? (live ? 'Sedang memantau ' + (g ? g.name : 'game') : 'Siaga. Buka salah satu game Anda.') : 'Nyalakan agar panel muncul saat game dibuka';
    var ck = '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>', x = '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>';
    function row(ok, t, sub) { return '<div class="check ' + (ok ? 'ok' : 'bad') + '"><span class="d">' + (ok ? ck : x) + '</span><div><span>' + t + '</span><small>' + sub + '</small></div></div>'; }
    $('#checks').innerHTML =
      row(S.root, 'Akses root', S.root ? 'Sudah diberikan' : 'Izinkan di Magisk atau KernelSU, lalu periksa ulang') +
      row(S.overlay, 'Jendela melayang', S.overlay ? 'Sudah diizinkan' : 'Diperlukan agar panel bisa tampil di atas game');
    var pb = $('#btnPerm');
    pb.hidden = S.root && S.overlay;
    pb.textContent = S.root ? 'Beri izin otomatis' : 'Periksa ulang akses root';
    $$('.game', $('#shelf')).forEach(function (el) { el.classList.toggle('live', !!live && el.dataset.pkg === S.game); });
  }

  /* ---------- tab Game ---------- */
  function renderModes() {
    var cur = S.cfg.defaultMode || 'turbo';
    var host = $('#modes'), el = seg(MODES.map(function (m) { return [m[0], m[1]]; }), cur, function (v) {
      S.cfg.defaultMode = v; call('mode', { id: v }); hint(v);
    }, 'modes compact');
    host.replaceWith(el); el.id = 'modes'; hint(cur);
    function hint(v) { var m = MODES.filter(function (x) { return x[0] === v; })[0]; $('#modeHint').textContent = ''; $('#modeNote').textContent = m ? m[2] : ''; }
  }
  function playtime() {
    var t = {}; sessions.forEach(function (s) { t[s.pkg] = (t[s.pkg] || 0) + s.dur; }); return t;
  }
  function renderShelf() {
    var pt = playtime(), keys = Object.keys(S.games);
    keys.sort(function (a, b) { return (pt[b] || 0) - (pt[a] || 0) || S.games[a].name.localeCompare(S.games[b].name); });
    $('#gameCount').textContent = keys.length ? keys.length + ' game' : '';
    var h = '';
    keys.forEach(function (p, i) {
      var g = S.games[p];
      h += '<button class="game" data-pkg="' + esc(p) + '" style="animation-delay:' + (i * 45) + 'ms"><div class="ic"></div><b>' + esc(g.name) + '</b><small>' + (pt[p] ? dur(pt[p]) : 'Belum main') + '</small></button>';
    });
    h += '<button class="game add" id="addGame" style="animation-delay:' + (keys.length * 45) + 'ms"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>Tambah game</button>';
    if (!keys.length) h = '<div class="empty">Belum ada game. Tambahkan game yang ingin dipantau, lalu panel akan muncul otomatis saat game dibuka.</div>' + h;
    var sh = $('#shelf'); sh.innerHTML = h;
    $$('.game[data-pkg]', sh).forEach(function (el) {
      iconInto($('.ic', el), el.dataset.pkg, S.games[el.dataset.pkg].name);
      el.addEventListener('click', function () { sfx('tap'); gameSheet(el.dataset.pkg); });
    });
    $('#addGame').addEventListener('click', function () { sfx('tap'); addSheet(); });
    renderStatus();
  }

  function gameSheet(pkg) {
    var g = S.games[pkg]; if (!g) return;
    openSheet('<div class="shead"><div class="ic"></div><div><h3>' + esc(g.name) + '</h3><small>' + esc(pkg) + '</small></div></div>' +
      '<button class="btn wide" id="gPlay" style="margin-top:0">Main sekarang</button><div id="gForm"></div>' +
      '<button class="btn danger wide" id="gDel">Hapus dari daftar</button>', function (b) {
      iconInto($('.ic', b), pkg, g.name);
      var f = $('#gForm', b);
      function set(k, v) { g[k] = v; call('setGame', { pkg: pkg, key: k, value: v }); }
      function field(t, sub, ctrl) {
        var d = document.createElement('div'); d.className = 'field';
        d.innerHTML = '<label>' + esc(t) + '</label>' + (sub ? '<small>' + esc(sub) + '</small>' : ''); d.appendChild(ctrl); f.appendChild(d);
      }
      field('Mode untuk game ini', 'Pilih "Ikut" untuk memakai mode bawaan.',
        seg([['', 'Ikut'], ['chill', 'Santai'], ['balance', 'Seimbang'], ['turbo', 'Ngebut'], ['tourney', 'Turnamen']], g.mode || '', function (v) { set('mode', v); }, 'compact'));
      var fw = document.createElement('div'); fw.className = 'row'; fw.style.marginTop = '6px';
      fw.innerHTML = '<div class="grow"><small style="color:var(--mute);font-size:12px">Matikan notifikasi pop-up dan kunci kecerahan</small></div>';
      fw.appendChild(sw(g.focus !== false, function (v) { set('focus', v); }, 'Mode fokus'));
      var fd = document.createElement('div'); fd.className = 'field'; fd.innerHTML = '<label>Mode fokus</label>'; fd.appendChild(fw); f.appendChild(fd);
      var perf = S.sdk >= 31;
      field('Resolusi game', perf ? 'Turunkan agar lebih ringan dan dingin.' : 'Perlu Android 12 ke atas.',
        seg([['', 'Asli'], ['0.9', '90%'], ['0.8', '80%'], ['0.7', '70%'], ['0.6', '60%']], g.down || '', function (v) { set('down', v); }, 'compact'));
      field('Batas FPS', perf ? 'Membatasi FPS membuat suhu lebih stabil.' : 'Perlu Android 12 ke atas.',
        seg([['', 'Bebas'], ['30', '30'], ['45', '45'], ['60', '60'], ['90', '90']], g.fps || '', function (v) { set('fps', v); }, 'compact'));
      field('Laju segar layar', 'Kosong berarti mengikuti mode.',
        seg([['', 'Ikut'], ['60', '60 Hz'], ['90', '90 Hz'], ['120', '120 Hz']], g.refresh || '', function (v) { set('refresh', v); }, 'compact'));
      $('#gPlay', b).addEventListener('click', function () {
        sfx('ok'); closeSheet();
        var m = g.mode || S.cfg.defaultMode || 'turbo';
        toast('Membuka ' + g.name + ' • mode ' + modeName(m));
        call('launch', { pkg: pkg }).then(function () { setTimeout(refresh, 1500); });
      });
      $('#gDel', b).addEventListener('click', function () {
        call('removeGame', { pkg: pkg }).then(function () { delete S.games[pkg]; closeSheet(); renderShelf(); toast(g.name + ' dihapus dari daftar'); });
      });
    });
  }
  function modeName(id) { var m = MODES.filter(function (x) { return x[0] === id; })[0]; return m ? m[1] : id; }

  var appCache = null;
  function addSheet() {
    openSheet('<h3>Tambah game</h3><p style="color:var(--mute);font-size:13px">Game yang terdeteksi ada di urutan atas.</p><input class="search" id="q" placeholder="Cari aplikasi" autocomplete="off"><div class="apps" id="apps"><div class="none">Memuat daftar aplikasi...</div></div>', function (b) {
      function draw() {
        var q = $('#q', b).value.trim().toLowerCase(), box = $('#apps', b);
        var list = (appCache || []).filter(function (a) { return !q || a.name.toLowerCase().indexOf(q) >= 0 || a.pkg.toLowerCase().indexOf(q) >= 0; }).slice(0, 80);
        box.innerHTML = list.length ? list.map(function (a) {
          return '<button class="app" data-pkg="' + esc(a.pkg) + '"><div class="ic"></div><div class="t"><b>' + esc(a.name) + '</b><small>' + (a.game ? 'Terdeteksi sebagai game' : esc(a.pkg)) + '</small></div><span class="plus' + (S.games[a.pkg] ? ' done' : '') + '">' + (S.games[a.pkg] ? 'Ditambahkan' : 'Tambah') + '</span></button>';
        }).join('') : '<div class="none">Tidak ada yang cocok.</div>';
        $$('.app', box).forEach(function (el) {
          iconInto($('.ic', el), el.dataset.pkg, el.querySelector('b').textContent);
          el.addEventListener('click', function () {
            var p = el.dataset.pkg; if (S.games[p]) return;
            call('addGame', { pkg: p }).then(function (r) {
              if (r && r.ok) { S.games[p] = r.conf; sfx('ok'); $('.plus', el).textContent = 'Ditambahkan'; $('.plus', el).classList.add('done'); renderShelf(); toast(r.conf.name + ' ditambahkan'); }
            });
          });
        });
      }
      $('#q', b).addEventListener('input', draw);
      if (appCache) draw(); else call('apps').then(function (a) { appCache = Array.isArray(a) ? a : []; draw(); });
    });
  }

  /* ---------- tab Laporan ---------- */
  function renderReport() {
    var last = sessions[0], box = $('#last');
    if (!last) {
      box.innerHTML = '<div class="card none">Belum ada sesi. Setelah Anda bermain lebih dari 20 detik, ringkasannya muncul di sini.</div>';
    } else {
      box.innerHTML = '<div class="card last"><div class="row"><div class="grow"><b>' + esc(last.name) + '</b><p>' + dstr(last.start) + ' • ' + dur(last.dur) + ' • mode ' + modeName(last.mode) + '</p></div></div>' +
        '<div class="big" style="margin-top:14px"><strong id="lAvg">0</strong><span>FPS rata-rata</span></div>' +
        '<div class="stats"><div class="stat"><b>' + (last.low || '--') + '</b><small>Terendah 1%</small></div><div class="stat"><b>' + (last.temp ? last.temp + '°' : '--') + '</b><small>Suhu maks</small></div><div class="stat"><b>' + (last.drop ? '-' + last.drop + '%' : '0%') + '</b><small>Baterai</small></div><div class="stat"><b>' + (last.ping >= 0 ? last.ping + ' ms' : '--') + '</b><small>Ping</small></div></div></div>';
      if (last.avg) countUp($('#lAvg'), last.avg); else $('#lAvg').textContent = '--';
    }
    // 7 hari
    var days = [], now = new Date(); now.setHours(0, 0, 0, 0);
    for (var i = 6; i >= 0; i--) { var d = new Date(now); d.setDate(d.getDate() - i); days.push({ t: d.getTime(), n: DAY[d.getDay()], m: 0, today: i === 0 }); }
    sessions.forEach(function (s) { days.forEach(function (d) { if (s.start >= d.t && s.start < d.t + 864e5) d.m += s.dur / 60; }); });
    var mx = Math.max.apply(null, days.map(function (d) { return d.m; }).concat([1])), tot = days.reduce(function (a, d) { return a + d.m; }, 0);
    $('#weekTotal').textContent = tot ? dur(tot * 60) + ' total' : '';
    $('#bars').innerHTML = days.map(function (d, k) {
      return '<div class="bar"><em>' + (d.m ? Math.round(d.m) : '') + '</em><i class="' + (d.m ? '' : 'z') + '" style="height:' + (d.m ? Math.max(6, d.m / mx * 86) : 4) + '%;animation-delay:' + (k * 60) + 'ms"></i><small' + (d.today ? ' style="color:var(--a3);font-weight:700"' : '') + '>' + d.n + '</small></div>';
    }).join('');
    // per game
    var pt = playtime(), ks = Object.keys(pt).sort(function (a, b) { return pt[b] - pt[a]; }), top = ks.length ? pt[ks[0]] : 1;
    $('#perGame').innerHTML = ks.length ? ks.slice(0, 8).map(function (p) {
      var n = (S.games[p] && S.games[p].name) || (sessions.filter(function (s) { return s.pkg === p; })[0] || {}).name || p;
      return '<div class="li" data-pkg="' + esc(p) + '"><div class="ic"></div><div class="t"><b>' + esc(n) + '</b><div class="meter"><i style="width:' + Math.max(4, pt[p] / top * 100) + '%"></i></div></div><div class="r">' + dur(pt[p]) + '</div></div>';
    }).join('') : '<div class="none">Belum ada data.</div>';
    $$('#perGame .li').forEach(function (el) { iconInto($('.ic', el), el.dataset.pkg, el.querySelector('b').textContent); });
    // riwayat
    $('#history').innerHTML = sessions.length ? sessions.slice(0, 20).map(function (s) {
      return '<div class="li"><div class="t"><b>' + esc(s.name) + '</b><small>' + dstr(s.start) + ' • ' + dur(s.dur) + '</small></div><div class="r">' + (s.avg ? s.avg + ' FPS' : '--') + '</div></div>';
    }).join('') : '<div class="none">Belum ada riwayat.</div>';
    $('#btnClear').hidden = !sessions.length;
  }

  /* ---------- tab Atur ---------- */
  function renderSettings() {
    var C = S.cfg, p = $('#setPanel'), h = $('#setHud'), g = $('#setGuard'), n = $('#setGen');
    p.innerHTML = h.innerHTML = g.innerHTML = n.innerHTML = '';
    opt(p, 'Sisi layar', 'Geser dari tepi untuk membuka panel', seg([['left', 'Kiri'], ['right', 'Kanan'], ['both', 'Dua sisi']], C.side, function (v) { cfgSet('side', v); }, 'three'), true);
    var em = seg([['edge', 'Tepi'], ['tab', 'Tab']], C.edgeMode, function (v) { cfgSet('edgeMode', v); }, 'two');
    opt(p, 'Bentuk gagang', 'Pilih "Tab" bila gestur kembali ikut terpicu', em, true);
    var r1 = range(10, 90, 1, Math.round(C.handleY * 100), function (v) { return v + '%'; }, function (v) { cfgSet('handleY', v / 100); });
    var o1 = opt(p, 'Posisi gagang', 'Tinggi gagang dari atas layar', null); o1.firstChild.appendChild(r1.val); o1.appendChild(r1.el);
    var r2 = range(80, 200, 10, C.handleLen, function (v) { return v + ' dp'; }, function (v) { cfgSet('handleLen', v); });
    var o2 = opt(p, 'Panjang gagang', 'Makin panjang makin mudah disentuh', null); o2.firstChild.appendChild(r2.val); o2.appendChild(r2.el);
    opt(p, 'Gagang tersembunyi', 'Tetap bisa digeser, tetapi tidak terlihat', sw(!!C.stealth, function (v) { cfgSet('stealth', v); }, 'Gagang tersembunyi'));
    var tb = document.createElement('button'); tb.className = 'btn ghost wide'; tb.textContent = 'Uji panel sekarang';
    tb.addEventListener('click', function () {
      call('testHandle').then(function (r) {
        if (r && r.ok) toast('Geser dari tepi layar untuk mencoba');
        else if (r && r.why === 'overlay') toast('Izinkan jendela melayang dulu');
        else toast('Tidak bisa membuka panel uji');
      });
    });
    var ob = document.createElement('div'); ob.className = 'opt'; ob.appendChild(tb); p.appendChild(ob);

    opt(h, 'Tampilkan info di layar', 'Angka kecil saat bermain', sw(!!C.hud, function (v) { cfgSet('hud', v); }, 'Info di layar'));
    var cs = seg([['tl', 'Kiri atas'], ['tr', 'Kanan atas'], ['bl', 'Kiri bawah'], ['br', 'Kanan bawah']], C.hudCorner, function (v) { cfgSet('hudCorner', v); }, 'compact');
    opt(h, 'Letak', '', cs, true);
    var ch = document.createElement('div'); ch.className = 'chips';
    [['hudFps', 'FPS'], ['hudTemp', 'Suhu'], ['hudPing', 'Ping'], ['hudBat', 'Baterai']].forEach(function (x) {
      var c = document.createElement('button'); c.className = 'chipb' + (C[x[0]] ? ' on' : ''); c.textContent = x[1];
      c.addEventListener('click', function () { sfx('tap'); C[x[0]] = !C[x[0]]; c.classList.toggle('on', C[x[0]]); cfgSet(x[0], C[x[0]]); });
      ch.appendChild(c);
    });
    opt(h, 'Yang ditampilkan', '', ch, true);
    var r3 = range(30, 100, 5, C.hudOpacity, function (v) { return v + '%'; }, function (v) { cfgSet('hudOpacity', v); });
    var o3 = opt(h, 'Kejelasan', '', null); o3.firstChild.appendChild(r3.val); o3.appendChild(r3.el);

    opt(g, 'Jaga suhu', 'Turunkan mode otomatis saat terlalu panas', sw(!!C.guard, function (v) { cfgSet('guard', v); }, 'Jaga suhu'));
    opt(g, 'Batas suhu', 'Mode Ngebut dan Turnamen turun ke Seimbang di atas suhu ini', stepper(C.guardTemp, 40, 56, 1, function (v) { return v + '°C'; }, function (v) { cfgSet('guardTemp', v); }));
    opt(g, 'Mode fokus', 'Matikan notifikasi pop-up dan kunci kecerahan saat main', sw(!!C.focus, function (v) { cfgSet('focus', v); }, 'Mode fokus'));

    var ti = document.createElement('input'); ti.className = 'text'; ti.value = C.pingHost || '1.1.1.1'; ti.autocomplete = 'off'; ti.setAttribute('autocapitalize', 'none');
    ti.addEventListener('change', function () { var v = ti.value.trim(); if (/^[A-Za-z0-9.\-]{3,100}$/.test(v)) { cfgSet('pingHost', v); toast('Server ping disimpan'); } else { ti.value = C.pingHost; toast('Alamat tidak valid'); } });
    opt(g, 'Server untuk ping', 'Alamat yang dipakai mengukur ping', ti, true);

    opt(n, 'Nyala otomatis', 'Jalankan pemantau setelah ponsel hidup', sw(!!C.autoStart, function (v) { cfgSet('autoStart', v); }, 'Nyala otomatis'));
    opt(n, 'Getar', 'Getaran halus saat panel dibuka', sw(C.haptic !== false, function (v) { cfgSet('haptic', v); }, 'Getar'));
    opt(n, 'Suara klik', 'Bunyi kecil di aplikasi ini', sw(store('snd') !== '0', function (v) { store('snd', v ? '1' : '0'); }, 'Suara klik'));
  }

  /* ---------- tab ---------- */
  function setTab(t) {
    if (t === tab) return;
    tab = t;
    $$('.page').forEach(function (p) { p.classList.toggle('active', p.id === 'p-' + t); });
    var i = ['game', 'report', 'set'].indexOf(t);
    $$('#tabs button').forEach(function (b) { b.classList.toggle('on', b.dataset.tab === t); });
    $('#tabs .glider').style.transform = 'translateX(' + (i * 100) + '%)';
    window.scrollTo({ top: 0 });
    if (t === 'report') loadSessions();
  }
  $$('#tabs button').forEach(function (b) { b.addEventListener('click', function () { sfx('tap'); setTab(b.dataset.tab); }); });
  $('#btnClear').addEventListener('click', function () {
    if (!confirmClear) { confirmClear = true; $('#btnClear').textContent = 'Ketuk lagi untuk menghapus'; setTimeout(function () { confirmClear = false; $('#btnClear').textContent = 'Hapus semua'; }, 3000); return; }
    confirmClear = false; call('clearSessions').then(function () { sessions = []; renderReport(); renderShelf(); toast('Riwayat dihapus'); $('#btnClear').textContent = 'Hapus semua'; });
  });
  var confirmClear = false;

  /* ---------- data ---------- */
  function loadSessions() {
    return call('sessions').then(function (a) { if (Array.isArray(a)) { sessions = a; if (tab === 'report') renderReport(); renderShelf(); } });
  }
  var firstState = true;
  function refresh() {
    return call('state').then(function (s) {
      if (!s || s.error) return;
      var changedCfg = JSON.stringify(s.cfg) !== JSON.stringify(S.cfg);
      var changedGames = JSON.stringify(s.games) !== JSON.stringify(S.games);
      S = s;
      if (firstState) { firstState = false; renderModes(); renderSettings(); renderShelf(); autoSetup(); }
      else { if (changedGames && !sheetOpen) renderShelf(); }
      renderStatus();
    });
  }
  function autoSetup() {
    if (S.root && !S.overlay && store('permTried') !== '1') {
      store('permTried', '1');
      call('perm').then(function () { return refresh(); });
    }
    if (S.root && S.overlay && !S.running && S.cfg.autoStart && Object.keys(S.games).length) {
      call('service', { on: true }).then(function () { setTimeout(refresh, 600); });
    }
  }
  $('#btnPerm').addEventListener('click', function () {
    if (!S.root) {
      toast('Memeriksa akses root...');
      call('rootcheck').then(function (r) { toast(r && r.root ? 'Akses root diberikan' : 'Akses root belum diberikan'); sfx(r && r.root ? 'ok' : 'tap'); return refresh(); });
      return;
    }
    call('perm').then(function () { return refresh(); }).then(function () {
      if (S.overlay) { toast('Semua izin sudah diberikan'); sfx('ok'); }
      else { toast('Aktifkan "Tampil di atas aplikasi lain" lalu kembali'); call('openOverlayPerm'); }
    });
  });
  $('#swService').addEventListener('click', function () {
    var on = !S.running;
    if (on && (!S.root || !S.overlay)) { toast(!S.root ? 'Butuh akses root dulu' : 'Izinkan jendela melayang dulu'); return; }
    sfx('tap');
    S.running = on; renderStatus();
    call('service', { on: on }).then(function () { setTimeout(refresh, 700); toast(on ? 'Panel game menyala' : 'Panel game dimatikan'); });
  });
  window.__resume = function () { refresh(); if (tab === 'report') loadSessions(); };
  window.__back = function () {
    if (sheetOpen) { closeSheet(); return true; }
    if (tab !== 'game') { setTab('game'); return true; }
    return false;
  };

  /* ---------- mulai ---------- */
  var v = $('#hero'); if (v) { var pl = v.play && v.play(); if (pl && pl.catch) pl.catch(function () { }); }
  setTimeout(function () { $('#splash').classList.add('hide'); }, 1900);
  refresh().then(loadSessions);
  setInterval(function () { if (!document.hidden && !sheetOpen) refresh(); }, 3000);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) refresh(); });
})();
