# Sion Game Space

Game Space khusus perangkat **root**: panel melayang yang dibuka dengan geser dari tepi layar,
4 mode performa, mode fokus, info FPS/suhu/ping di layar, foto dan rekam layar tanpa dialog,
laporan sesi, dan semua perubahan dikembalikan otomatis saat game ditutup.

## Cara mendapatkan APK (lewat GitHub)

1. Buat repositori baru di GitHub (boleh privat).
2. Unggah **seluruh isi folder ini** (termasuk folder `.github`, `app`, dan `gradle` jika ada).
   Cara paling mudah: di halaman repositori pilih *Add file → Upload files*, tarik semua isi folder.
   Pastikan folder tersembunyi `.github/workflows/build.yml` ikut terunggah.
3. Buka tab **Actions**. Workflow **Build APK** berjalan sendiri (atau pilih *Run workflow*).
4. Setelah centang hijau (sekitar 3-5 menit), buka run tersebut, lalu unduh **SionGameSpace-APK** di bagian *Artifacts*.
5. Ekstrak zip-nya, pasang `SionGameSpace.apk` di ponsel.

Jika build gagal (tanda silang merah), buka run itu, salin baris yang berawalan `error:` dan kirim ke saya. Project ini belum pernah dikompilasi di Android SDK sungguhan, jadi satu-dua perbaikan kecil pada build pertama itu wajar.

## Pemakaian pertama

1. Buka aplikasi, izinkan akses **root** (Magisk / KernelSU) saat diminta.
2. Aplikasi memberi izin otomatis lewat root. Bila "Jendela melayang" masih belum aktif, ketuk tombol izin lalu aktifkan *Tampil di atas aplikasi lain*.
3. Tab **Game → Tambah game**, pilih game Anda.
4. Nyalakan **Panel game**. Buka game, lalu geser dari tepi layar (kanan secara bawaan) untuk membuka panel.
5. Tab **Atur → Uji panel sekarang** untuk mencoba panel tanpa membuka game.

## Gestur kembali ikut terpicu?

Aplikasi memakai tiga lapis: zona kecualian gestur di gagang, pengurangan lebar gestur kembali lewat root selama game
(dikembalikan sesudahnya), dan bentuk gagang **Tab** (agak masuk dari tepi). Hasilnya berbeda di tiap ROM.
Bila masih terpicu: Atur → Bentuk gagang → **Tab**, atau geser posisi gagang ke tengah layar.

## Catatan

- Mode Ngebut/Turnamen mengubah batas frekuensi CPU/GPU lewat sysfs. Beberapa ROM menolak sebagian node; yang gagal dilewati dan tidak merusak apa pun.
- Batas resolusi dan FPS per game memakai `cmd game` (Android 12+).
- Game dengan anti-cheat ketat dapat menganggap perubahan sistem sebagai risiko. Pakai dengan kesadaran sendiri.
- Tanda tangan APK memakai keystore tetap di `app/gamespace.jks` (kata sandi `gamespace123`), jadi pembaruan bisa menimpa versi lama.
