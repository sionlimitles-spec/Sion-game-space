package com.sion.gamespace;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Penyimpanan sederhana (SharedPreferences berisi JSON). */
final class Store {
    private static final String DEFAULT_CFG =
            "{\"defaultMode\":\"turbo\",\"side\":\"right\",\"handleY\":0.38,\"handleLen\":150,"
            + "\"edgeMode\":\"edge\",\"stealth\":false,\"hud\":true,\"hudCorner\":\"tl\","
            + "\"hudFps\":true,\"hudTemp\":true,\"hudPing\":true,\"hudBat\":false,\"hudOpacity\":85,"
            + "\"pingHost\":\"1.1.1.1\",\"guard\":true,\"guardTemp\":48,\"autoStart\":true,"
            + "\"focus\":true,\"haptic\":true}";

    private final SharedPreferences sp;

    Store(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("gs", Context.MODE_PRIVATE);
    }

    synchronized JSONObject cfg() {
        try {
            JSONObject base = new JSONObject(DEFAULT_CFG);
            JSONObject cur = new JSONObject(sp.getString("cfg", "{}"));
            java.util.Iterator<String> it = cur.keys();
            while (it.hasNext()) {
                String k = it.next();
                base.put(k, cur.get(k));
            }
            return base;
        } catch (JSONException e) {
            try { return new JSONObject(DEFAULT_CFG); } catch (JSONException x) { return new JSONObject(); }
        }
    }

    synchronized void putCfg(String key, Object value) {
        try {
            JSONObject cur = new JSONObject(sp.getString("cfg", "{}"));
            cur.put(key, value);
            sp.edit().putString("cfg", cur.toString()).apply();
        } catch (JSONException ignored) { }
    }

    synchronized JSONObject games() {
        try { return new JSONObject(sp.getString("games", "{}")); } catch (JSONException e) { return new JSONObject(); }
    }

    synchronized void putGame(String pkg, JSONObject conf) {
        try {
            JSONObject g = games();
            g.put(pkg, conf);
            sp.edit().putString("games", g.toString()).apply();
        } catch (JSONException ignored) { }
    }

    synchronized void removeGame(String pkg) {
        JSONObject g = games();
        g.remove(pkg);
        sp.edit().putString("games", g.toString()).apply();
    }

    synchronized boolean hasGame(String pkg) {
        return games().has(pkg);
    }

    synchronized JSONArray sessions() {
        try { return new JSONArray(sp.getString("sessions", "[]")); } catch (JSONException e) { return new JSONArray(); }
    }

    synchronized void addSession(JSONObject s) {
        JSONArray cur = sessions();
        JSONArray next = new JSONArray();
        next.put(s);
        for (int i = 0; i < cur.length() && next.length() < 200; i++) {
            try { next.put(cur.get(i)); } catch (JSONException ignored) { }
        }
        sp.edit().putString("sessions", next.toString()).apply();
    }

    synchronized void clearSessions() {
        sp.edit().putString("sessions", "[]").apply();
    }
}
