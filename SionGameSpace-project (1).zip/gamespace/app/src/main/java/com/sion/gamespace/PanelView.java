package com.sion.gamespace;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Panel samping: kartu kaca neon berisi FPS, data, mode, dan aksi cepat. Warna mengikuti mode. */
final class PanelView extends FrameLayout {
    interface DragListener {
        void onDragStart();
        void onDrag(float p);
        void onDragEnd(boolean close);
    }

    /** Lebar kartu dalam satuan gambar rancangan (px). */
    static final float DESIGN_W = 540f;

    private final Overlay.Host host;
    private final boolean right;
    private final float u;
    private final int cardW;
    private final int tabW;
    private final FrameLayout card;
    private final PanelBg bg;
    private final LinearLayout content;
    private final TextView title, sub, gameName, fpsBig, fpsLabel;
    private final LogoView logo;
    private final ArtView art;
    private final GraphView graph;
    private final GradientDrawable fpsBox;
    private final StatView sTemp, sPing, sBat, sCpu;
    private final BarView close, modeRow, openBar;
    private final ModeBar modes;
    private final ChevronTab tab;
    private final List<TileView> tiles = new ArrayList<TileView>();
    private final List<View> stagger = new ArrayList<View>();
    private int shownFps;
    private ValueAnimator fpsAnim;
    private ValueAnimator themeAnim;
    private Theme theme;
    private String modeId;
    private DragListener dragListener;

    PanelView(Context c, Overlay.Host host, boolean right, float u) {
        super(c);
        this.host = host;
        this.right = right;
        this.u = u;
        cardW = Math.round(DESIGN_W * u);
        tabW = Math.round(34 * u);
        setClipChildren(false);
        modeId = host.activeMode();
        theme = Theme.of(modeId);

        card = new FrameLayout(c);
        bg = new PanelBg(34 * u, u);
        card.setBackground(bg);
        card.setClipChildren(false);
        LayoutParams cp = new LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.gravity = (right ? Gravity.RIGHT : Gravity.LEFT) | Gravity.CENTER_VERTICAL;
        cp.topMargin = Math.round(6 * u);
        cp.bottomMargin = Math.round(6 * u);
        addView(card, cp);

        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        card.addView(sv, new LayoutParams(-1, -2));

        content = new LinearLayout(c);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = Math.round(24 * u);
        content.setPadding(pad, Math.round(20 * u), pad, Math.round(22 * u));
        sv.addView(content, new ViewGroup.LayoutParams(-1, -2));

        // ---- judul
        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        logo = new LogoView(c);
        head.addView(logo, new LinearLayout.LayoutParams(Math.round(62 * u), Math.round(62 * u)));
        LinearLayout tcol = new LinearLayout(c);
        tcol.setOrientation(LinearLayout.VERTICAL);
        title = text(c, "Sion Game Space", 25, 0xFFFFFFFF);
        title.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC));
        title.setSingleLine(true);
        sub = text(c, "Game Booster • Performance • More", 14, 0xFFC4D2EA);
        sub.setSingleLine(true);
        tcol.addView(title);
        tcol.addView(sub);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, -2, 1f);
        tp.leftMargin = Math.round(10 * u);
        head.addView(tcol, tp);
        close = new BarView(c, BarView.CLOSE, "Tutup", u);
        close.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { PanelView.this.host.closePanel(); }
        });
        head.addView(close, new LinearLayout.LayoutParams(Math.round(112 * u), Math.round(40 * u)));
        content.addView(head, new LinearLayout.LayoutParams(-1, Math.round(66 * u)));
        stagger.add(head);

        // ---- kartu FPS
        FrameLayout fpsCard = new FrameLayout(c);
        fpsBox = new GradientDrawable();
        fpsBox.setCornerRadius(24 * u);
        fpsBox.setColor(0x40000000);
        fpsCard.setBackground(fpsBox);
        final float rr = 24 * u;
        fpsCard.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), rr); }
        });
        fpsCard.setClipToOutline(true);
        art = new ArtView(c);
        fpsCard.addView(art, new LayoutParams(Math.round(300 * u), Math.round(150 * u), Gravity.RIGHT | Gravity.TOP));
        graph = new GraphView(c, u);
        fpsCard.addView(graph, new LayoutParams(-1, Math.round(78 * u), Gravity.BOTTOM));
        LinearLayout fl = new LinearLayout(c);
        fl.setOrientation(LinearLayout.VERTICAL);
        fl.setPadding(Math.round(22 * u), Math.round(12 * u), 0, 0);
        gameName = text(c, "", 15, 0xFFC4D2EA);
        gameName.setSingleLine(true);
        gameName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        gameName.setMaxWidth(Math.round(240 * u));
        LinearLayout fr = new LinearLayout(c);
        fr.setOrientation(LinearLayout.HORIZONTAL);
        fr.setGravity(Gravity.BOTTOM);
        fpsBig = text(c, "--", 88, 0xFFFFFFFF);
        fpsBig.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC));
        fpsBig.setShadowLayer(18 * u, 0, 0, theme.a2);
        fpsLabel = text(c, "FPS", 30, theme.a3);
        fpsLabel.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC));
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-2, -2);
        flp.leftMargin = Math.round(8 * u);
        flp.bottomMargin = Math.round(12 * u);
        fr.addView(fpsBig);
        fr.addView(fpsLabel, flp);
        fl.addView(gameName);
        fl.addView(fr);
        fpsCard.addView(fl, new LayoutParams(-2, -2, Gravity.LEFT | Gravity.TOP));
        LinearLayout.LayoutParams fcp = new LinearLayout.LayoutParams(-1, Math.round(196 * u));
        fcp.topMargin = Math.round(8 * u);
        content.addView(fpsCard, fcp);
        stagger.add(fpsCard);

        // ---- 4 kotak data
        LinearLayout stats = new LinearLayout(c);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        sTemp = stat(c, stats, StatView.THERMO, "Suhu", 0);
        sPing = stat(c, stats, StatView.SIGNAL, "Ping", 1);
        sBat = stat(c, stats, StatView.BATT, "Baterai", 1);
        sCpu = stat(c, stats, StatView.CHIP, "CPU", 1);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, Math.round(112 * u));
        sp.topMargin = Math.round(14 * u);
        content.addView(stats, sp);
        stagger.add(stats);

        // ---- baris mode
        modeRow = new BarView(c, BarView.MODE, "Mode " + Gs.modeName(modeId), u);
        modeRow.setMode(modeId, "Mode " + Gs.modeName(modeId));
        modeRow.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) {
                String cur = PanelView.this.host.activeMode();
                String next = "chill".equals(cur) ? "balance" : "balance".equals(cur) ? "turbo" : "chill";
                PanelView.this.host.setMode(next);
                syncMode(next, true);
            }
        });
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, Math.round(58 * u));
        mp.topMargin = Math.round(14 * u);
        content.addView(modeRow, mp);
        stagger.add(modeRow);

        modes = new ModeBar(c, u);
        modes.setListener(new ModeBar.Listener() {
            @Override public void onMode(String id) { PanelView.this.host.setMode(id); syncMode(id, true); }
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, Math.round(54 * u));
        bp.topMargin = Math.round(8 * u);
        content.addView(modes, bp);
        stagger.add(modes);

        // ---- ubin aksi cepat
        String[][] defs = {
                {"focus", "Fokus"}, {"ram", "RAM"}, {"shot", "Foto"}, {"rec", "Rekam"},
                {"refresh", "Layar"}, {"wifi", "Wi-Fi"}, {"bright", "Terang"}, {"settings", "Atur"}};
        int[] icons = {TileView.FOCUS, TileView.RAM, TileView.SHOT, TileView.REC,
                TileView.REFRESH, TileView.WIFI, TileView.BRIGHT, TileView.GEAR};
        for (int rI = 0; rI < 2; rI++) {
            LinearLayout tr = new LinearLayout(c);
            tr.setOrientation(LinearLayout.HORIZONTAL);
            for (int k = 0; k < 4; k++) {
                int i = rI * 4 + k;
                TileView t = new TileView(c, defs[i][0], icons[i], defs[i][1], u);
                t.setOnTile(new TileView.Click() {
                    @Override public void onClick(TileView tv) { PanelView.this.host.tile(tv.id); refreshTiles(); }
                });
                tiles.add(t);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1f);
                if (k > 0) lp.leftMargin = Math.round(8 * u);
                tr.addView(t, lp);
            }
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, Math.round(92 * u));
            rp.topMargin = Math.round((rI == 0 ? 14 : 8) * u);
            content.addView(tr, rp);
            stagger.add(tr);
        }

        openBar = new BarView(c, BarView.OPEN, "Buka Sion Game Space", u);
        openBar.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { PanelView.this.host.openApp(); }
        });
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, Math.round(60 * u));
        op.topMargin = Math.round(14 * u);
        content.addView(openBar, op);
        stagger.add(openBar);

        // ---- tab tutup di sisi dalam
        tab = new ChevronTab(c, right, u);
        tab.setListener(new ChevronTab.Listener() {
            @Override public void onStart() { if (dragListener != null) dragListener.onDragStart(); }
            @Override public void onDrag(float dx) { if (dragListener != null) dragListener.onDrag(Math.max(0f, 1f - dx / cardW)); }
            @Override public void onEnd(boolean closeIt, float v) { if (dragListener != null) dragListener.onDragEnd(closeIt); }
        });
        LayoutParams tl = new LayoutParams(tabW, Math.round(150 * u), (right ? Gravity.RIGHT : Gravity.LEFT) | Gravity.CENTER_VERTICAL);
        if (right) tl.rightMargin = cardW - tabW / 2; else tl.leftMargin = cardW - tabW / 2;
        addView(tab, tl);

        applyTheme(theme);
    }

    private TextView text(Context c, String s, float designPx, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, Math.max(designPx * u, 8f * c.getResources().getDisplayMetrics().density));
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        return t;
    }

    private StatView stat(Context c, LinearLayout parent, int kind, String label, int idx) {
        StatView v = new StatView(c, kind, label, u);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1f);
        if (idx > 0) lp.leftMargin = Math.round(8 * u);
        parent.addView(v, lp);
        return v;
    }

    void setDragListener(DragListener l) { dragListener = l; }

    int panelExtent() { return cardW + tabW; }

    // ------------------------------------------------------------ tema

    private void applyTheme(Theme t) {
        theme = t;
        bg.setTheme(t);
        logo.setTheme(t);
        art.setTheme(t);
        graph.setTheme(t);
        modes.setTheme(t);
        close.setTheme(t);
        modeRow.setTheme(t);
        openBar.setTheme(t);
        tab.setTheme(t);
        sTemp.setTheme(t); sPing.setTheme(t); sBat.setTheme(t); sCpu.setTheme(t);
        for (TileView tv : tiles) tv.setTheme(t);
        fpsBox.setStroke(Math.max(1, Math.round(1.5f * u)), (0x88 << 24) | (t.a2 & 0xFFFFFF));
        fpsLabel.setTextColor(t.a3);
        fpsBig.setShadowLayer(18 * u, 0, 0, t.a2);
    }

    /** Ganti mode di tampilan panel. Warna berubah halus. */
    void syncMode(String id, boolean animate) {
        final Theme to = Theme.of(id);
        modeId = id;
        modeRow.setMode(id, "Mode " + Gs.modeName(id));
        modes.select(id, animate);
        if (themeAnim != null) themeAnim.cancel();
        if (!animate) { applyTheme(to); return; }
        final Theme from = theme;
        themeAnim = ValueAnimator.ofFloat(0f, 1f);
        themeAnim.setDuration(520);
        themeAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) { applyTheme(Theme.lerp(from, to, (Float) a.getAnimatedValue())); }
        });
        themeAnim.start();
    }

    // ------------------------------------------------------------ isi

    void setGame(String name) {
        gameName.setText(name == null || name.length() == 0 ? "Mode panel" : name);
    }

    void refreshTiles() {
        for (TileView t : tiles) {
            if ("settings".equals(t.id)) continue;
            t.setOn(host.tileOn(t.id), true);
            String s = host.tileSub(t.id);
            if (s != null) t.setSub(s);
        }
        String m = host.activeMode();
        if (!m.equals(modeId)) syncMode(m, true);
    }

    void syncNow() {
        for (TileView t : tiles) {
            if ("settings".equals(t.id)) continue;
            t.setOn(host.tileOn(t.id), false);
            String s = host.tileSub(t.id);
            if (s != null) t.setSub(s);
        }
        syncMode(host.activeMode(), false);
    }

    TileView tile(String id) {
        for (TileView t : tiles) if (t.id.equals(id)) return t;
        return null;
    }

    void bind(Metrics m, boolean good) {
        if (m == null) return;
        animateFps(m.fps);
        graph.setData(m.ft);
        sTemp.set(m.temp() > 0 ? m.temp() + "°C" : "--", m.temp() >= 46, 0);
        sPing.set(m.ping >= 0 ? m.ping + " ms" : "--", false, 0);
        sBat.set(m.bat >= 0 ? m.bat + "%" : "--", false, m.bat >= 0 ? m.bat / 100f : 0.5f);
        sCpu.set(m.cpuLoad >= 0 ? Math.round(m.cpuLoad) + "%" : "--", false, 0);
    }

    private void animateFps(int to) {
        if (to <= 0) { fpsBig.setText("--"); shownFps = 0; return; }
        if (fpsAnim != null) fpsAnim.cancel();
        fpsAnim = ValueAnimator.ofInt(shownFps, to);
        fpsAnim.setDuration(420);
        fpsAnim.setInterpolator(new DecelerateInterpolator());
        fpsAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                shownFps = (Integer) a.getAnimatedValue();
                fpsBig.setText(String.valueOf(shownFps));
            }
        });
        fpsAnim.start();
    }

    /** Geser panel mengikuti jari. p=0 tersembunyi, p=1 terbuka penuh. */
    void reveal(float p) {
        float dist = cardW + tabW;
        setTranslationX((right ? 1 : -1) * (1f - p) * dist);
        setAlpha(0.25f + 0.75f * Math.min(1f, p));
    }

    /** Animasi masuk berurutan untuk isi kartu. */
    void animateIn() {
        int i = 0;
        for (View v : stagger) {
            v.setAlpha(0f);
            v.setTranslationX((right ? 1 : -1) * 26 * u);
            v.animate().alpha(1f).translationX(0f).setStartDelay(50L + i * 36L).setDuration(340)
                    .setInterpolator(new DecelerateInterpolator(1.8f)).start();
            i++;
        }
    }

    void cancelAnims() {
        if (fpsAnim != null) fpsAnim.cancel();
        if (themeAnim != null) themeAnim.cancel();
        for (View v : stagger) v.animate().cancel();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        // sentuhan di luar kartu menutup panel
        if (e.getAction() == MotionEvent.ACTION_DOWN) host.closePanel();
        return true;
    }
}
