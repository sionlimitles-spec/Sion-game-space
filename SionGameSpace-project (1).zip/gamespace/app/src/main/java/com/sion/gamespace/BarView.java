package com.sion.gamespace;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/** Tombol lebar bergaya kaca: Tutup, baris mode, dan tautan buka aplikasi. */
final class BarView extends View {
    static final int CLOSE = 0, MODE = 1, OPEN = 2;
    private final int kind;
    private final float u;
    private String text;
    private String mode = "balance";
    private Theme t = Theme.SEIMBANG;
    private float press;
    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ink = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tx = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();

    BarView(Context c, int kind, String text, float u) {
        super(c);
        this.kind = kind;
        this.text = text;
        this.u = u;
        ink.setStrokeWidth(Math.max(1.5f, u * 2.6f));
        ink.setStrokeCap(Paint.Cap.ROUND);
        ink.setStrokeJoin(Paint.Join.ROUND);
        tx.setTypeface(kind == CLOSE ? Typeface.DEFAULT : Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        tx.setTextSize(u * (kind == CLOSE ? 21 : 23));
        setClickable(true);
    }

    void setTheme(Theme th) { t = th; invalidate(); }

    void setMode(String m, String label) { mode = m; text = label; invalidate(); }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getAction();
        if (a == MotionEvent.ACTION_DOWN) { anim(1f); return true; }
        if (a == MotionEvent.ACTION_UP) {
            anim(0f);
            if (e.getX() >= 0 && e.getX() <= getWidth() && e.getY() >= 0 && e.getY() <= getHeight()) {
                performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
                performClick();
            }
            return true;
        }
        if (a == MotionEvent.ACTION_CANCEL) anim(0f);
        return true;
    }

    @Override public boolean performClick() { return super.performClick(); }

    private void anim(float to) {
        ValueAnimator v = ValueAnimator.ofFloat(press, to);
        v.setDuration(to > 0 ? 90 : 220);
        v.setInterpolator(to > 0 ? new DecelerateInterpolator() : new OvershootInterpolator(2f));
        v.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) { press = (Float) a.getAnimatedValue(); invalidate(); }
        });
        v.start();
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        float sc = 1f - 0.05f * press;
        c.save();
        c.scale(sc, sc, w / 2f, h / 2f);
        float rad = kind == CLOSE ? h / 2f : h * 0.42f;
        r.set(1, 1, w - 1, h - 1);
        bg.setStyle(Paint.Style.FILL);
        if (kind == OPEN) {
            bg.setShader(new LinearGradient(0, 0, w, 0, (0x55 << 24) | (t.a1 & 0xFFFFFF), (0x14 << 24) | (t.a2 & 0xFFFFFF), Shader.TileMode.CLAMP));
        } else {
            bg.setColor(0x44000000);
        }
        c.drawRoundRect(r, rad, rad, bg);
        bg.setShader(null);
        bg.setStyle(Paint.Style.STROKE);
        bg.setStrokeWidth(Math.max(1f, u * 1.6f));
        bg.setShader(new LinearGradient(0, 0, w, 0, t.a3, t.a1, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, bg);
        bg.setShader(null);
        ink.setColor(t.a3);
        tx.setColor(0xFFFFFFFF);
        float cy = h / 2f;
        float ty = cy + tx.getTextSize() * 0.35f;
        float s = h * 0.27f;
        if (kind == CLOSE) {
            tx.setTextAlign(Paint.Align.LEFT);
            c.drawText(text, h * 0.45f, ty, tx);
            Icons.cross(c, w - h * 0.5f, cy, s * 0.75f, ink);
        } else if (kind == MODE) {
            Icons.modeIcon(c, mode, h * 0.6f, cy, s, ink);
            tx.setTextAlign(Paint.Align.LEFT);
            c.drawText(text, h * 1.05f, ty, tx);
            Icons.chevron(c, w - h * 0.5f, cy, s * 0.8f, ink, 1);
        } else {
            Paint lg = new Paint(Paint.ANTI_ALIAS_FLAG);
            lg.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC));
            lg.setTextSkewX(-0.22f);
            lg.setTextAlign(Paint.Align.CENTER);
            lg.setTextSize(h * 0.8f);
            lg.setShader(new LinearGradient(0, 0, h, h, t.a3, t.a1, Shader.TileMode.CLAMP));
            c.drawText("S", h * 0.75f, cy + h * 0.28f, lg);
            tx.setTextAlign(Paint.Align.LEFT);
            c.drawText(text, h * 1.3f, ty, tx);
            Icons.chevron(c, w - h * 0.55f, cy, s * 0.8f, ink, 1);
        }
        c.restore();
    }
}
