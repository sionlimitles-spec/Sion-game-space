package com.sion.gamespace;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Jembatan JavaScript: antarmuka web memanggil GS.api(perintah, json, idBalasan). */
final class Bridge {
    private final Activity act;
    private final WebView web;
    private final Store store;
    private final ExecutorService pool = Executors.newFixedThreadPool(2);

    Bridge(Activity a, WebView w) {
        act = a;
        web = w;
        store = new Store(a);
    }

    @JavascriptInterface
    public void api(final String cmd, final String json, final String cb) {
        pool.execute(new Runnable() {
            @Override public void run() {
                String res;
                try {
                    JSONObject a = json == null || json.length() == 0 ? new JSONObject() : new JSONObject(json);
                    res = handle(cmd, a);
                } catch (Throwable t) {
                    res = "{\"error\":" + JSONObject.quote(String.valueOf(t.getMessage())) + "}";
                }
                final String out = res;
                web.post(new Runnable() {
                    @Override public void run() {
                        web.evaluateJavascript("window.__gs_cb&&window.__gs_cb(" + JSONObject.quote(cb) + ","
                                + JSONObject.quote(out) + ")", null);
                    }
                });
            }
        });
    }

    private String ok() { return "{\"ok\":true}"; }

    private String handle(String cmd, JSONObject a) throws JSONException {
        if ("state".equals(cmd)) return state().toString();
        if ("apps".equals(cmd)) return apps().toString();
        if ("icon".equals(cmd)) return JSONObject.quote(icon(a.optString("pkg")));
        if ("addGame".equals(cmd)) return addGame(a.optString("pkg"));
        if ("removeGame".equals(cmd)) { store.removeGame(a.optString("pkg")); return ok(); }
        if ("setGame".equals(cmd)) return setGame(a);
        if ("setCfg".equals(cmd)) return setCfg(a);
        if ("perm".equals(cmd)) {
            Map<String, String> r = Gs.kv(Gs.sh(act, 0, "perm"));
            return new JSONObject().put("ok", "ok".equals(r.get("perm"))).toString();
        }
        if ("service".equals(cmd)) return service(a.optBoolean("on", true));
        if ("launch".equals(cmd)) return launch(a.optString("pkg"));
        if ("mode".equals(cmd)) { store.putCfg("defaultMode", Gs.normMode(a.optString("id"))); return ok(); }
        if ("sessions".equals(cmd)) return store.sessions().toString();
        if ("shot".equals(cmd)) return new JSONObject(Gs.kv(Gs.sh(act, 0, "shot"))).toString();
        if ("rec".equals(cmd)) return new JSONObject(Gs.kv(Gs.sh(act, 0, "rec " + ("start".equals(a.optString("do")) ? "start" : "stop")))).toString();
        if ("rootcheck".equals(cmd)) return new JSONObject().put("root", RootShell.get(0).recheck()).toString();
        if ("openOverlayPerm".equals(cmd)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + Gs.PKG));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(i);
            return ok();
        }
        if ("clearSessions".equals(cmd)) { store.clearSessions(); return ok(); }
        if ("testHandle".equals(cmd)) {
            if (!Settings.canDrawOverlays(act)) return new JSONObject().put("ok", false).put("why", "overlay").toString();
            Intent i = new Intent(act, GameService.class).setAction(GameService.ACT_PREVIEW);
            act.startForegroundService(i);
            return ok();
        }
        return "{\"error\":\"perintah tidak dikenal\"}";
    }

    private JSONObject state() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("root", RootShell.get(0).isRoot());
        o.put("overlay", Settings.canDrawOverlays(act));
        GameService g = GameService.get();
        o.put("running", g != null && g.isRunning());
        o.put("game", g == null || g.activeGame() == null ? "" : g.activeGame());
        o.put("cfg", store.cfg());
        o.put("games", store.games());
        o.put("sdk", android.os.Build.VERSION.SDK_INT);
        return o;
    }

    private JSONArray apps() throws JSONException {
        PackageManager pm = act.getPackageManager();
        List<ApplicationInfo> all = pm.getInstalledApplications(0);
        final List<JSONObject> list = new ArrayList<JSONObject>();
        JSONObject have = store.games();
        for (ApplicationInfo ai : all) {
            if (ai.packageName.equals(Gs.PKG)) continue;
            if (pm.getLaunchIntentForPackage(ai.packageName) == null) continue;
            boolean game = (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0
                    || (android.os.Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME);
            JSONObject o = new JSONObject();
            o.put("pkg", ai.packageName);
            o.put("name", String.valueOf(pm.getApplicationLabel(ai)));
            o.put("game", game);
            o.put("added", have.has(ai.packageName));
            list.add(o);
        }
        Collections.sort(list, new Comparator<JSONObject>() {
            @Override public int compare(JSONObject x, JSONObject y) {
                boolean gx = x.optBoolean("game"), gy = y.optBoolean("game");
                if (gx != gy) return gx ? -1 : 1;
                return x.optString("name").compareToIgnoreCase(y.optString("name"));
            }
        });
        return new JSONArray(list);
    }

    private String icon(String pkg) {
        try {
            Drawable d = act.getPackageManager().getApplicationIcon(pkg);
            int n = 96;
            Bitmap b = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            d.setBounds(0, 0, n, n);
            d.draw(c);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.PNG, 90, bo);
            b.recycle();
            return "data:image/png;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    private String addGame(String pkg) throws JSONException {
        if (!Gs.validPkg(pkg)) return "{\"ok\":false}";
        PackageManager pm = act.getPackageManager();
        String name = pkg;
        try { name = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0))); } catch (Exception ignored) { }
        JSONObject conf = new JSONObject();
        conf.put("name", name);
        conf.put("mode", "");
        conf.put("focus", true);
        conf.put("down", "");
        conf.put("fps", "");
        conf.put("refresh", "");
        store.putGame(pkg, conf);
        return new JSONObject().put("ok", true).put("conf", conf).toString();
    }

    private String setGame(JSONObject a) throws JSONException {
        String pkg = a.optString("pkg");
        JSONObject g = store.games().optJSONObject(pkg);
        if (g == null) return "{\"ok\":false}";
        g.put(a.optString("key"), a.opt("value"));
        store.putGame(pkg, g);
        return ok();
    }

    private String setCfg(JSONObject a) throws JSONException {
        String k = a.optString("key");
        store.putCfg(k, a.opt("value"));
        GameService g = GameService.get();
        if (g != null && g.isRunning()) {
            act.startService(new Intent(act, GameService.class).setAction(GameService.ACT_REFRESH));
        }
        return ok();
    }

    private String service(boolean on) {
        Intent i = new Intent(act, GameService.class).setAction(on ? GameService.ACT_START : GameService.ACT_STOP);
        if (on) act.startForegroundService(i); else act.startService(i);
        return ok();
    }

    private String launch(String pkg) throws JSONException {
        if (!Gs.validPkg(pkg)) return "{\"ok\":false}";
        GameService g = GameService.get();
        if (g == null || !g.isRunning()) act.startForegroundService(new Intent(act, GameService.class).setAction(GameService.ACT_START));
        Intent li = act.getPackageManager().getLaunchIntentForPackage(pkg);
        if (li != null) {
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(li);
            return ok();
        }
        Gs.sh(act, 0, "launch " + pkg);
        return ok();
    }
}
