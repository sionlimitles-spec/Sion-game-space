package com.sion.gamespace;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.view.View;

/** Gelombang waktu per frame (ms). Makin rendah dan rata makin mulus. */
final class GraphView extends View {
    private float[] data = new float[0];
    private Theme t = Theme.SEIMBANG;
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Path area = new Path();
    private final float px;

    GraphView(Context c, float onePx) {
        super(c);
        px = Math.max(1f, onePx);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(px * 2.6f);
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setStrokeCap(Paint.Cap.ROUND);
        halo.setStyle(Paint.Style.STROKE);
        halo.setStrokeWidth(px * 9f);
        halo.setStrokeJoin(Paint.Join.ROUND);
        halo.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
    }

    void setTheme(Theme th) { t = th; rebuildShaders(); invalidate(); }

    void setData(float[] d) {
        data = d == null ? new float[0] : d;
        invalidate();
    }

    private void rebuildShaders() {
        int h = getHeight(), w = getWidth();
        if (h <= 0) return;
        fill.setShader(new LinearGradient(0, 0, 0, h, (0x66 << 24) | (t.a2 & 0xFFFFFF), (0x00 << 24) | (t.a2 & 0xFFFFFF), Shader.TileMode.CLAMP));
        line.setShader(new LinearGradient(0, 0, w, 0, t.a2, t.a3, Shader.TileMode.CLAMP));
        halo.setColor((0x33 << 24) | (t.a2 & 0xFFFFFF));
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) { rebuildShaders(); }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        int n = data.length;
        if (n < 2) {
            // garis datar saat belum ada data
            path.reset();
            path.moveTo(0, h * 0.6f);
            path.lineTo(w, h * 0.6f);
            canvas.drawPath(path, line);
            return;
        }
        float max = 25f;
        for (float v : data) if (v > max) max = v;
        max *= 1.15f;
        float step = w / (float) (n - 1);
        path.reset();
        area.reset();
        float px0 = 0, py0 = 0;
        for (int i = 0; i < n; i++) {
            float x = i * step;
            float y = h - px - Math.min(1f, data[i] / max) * (h - px * 6);
            if (i == 0) {
                path.moveTo(x, y);
                area.moveTo(x, h);
                area.lineTo(x, y);
            } else {
                float mx = (px0 + x) / 2f, my = (py0 + y) / 2f;
                path.quadTo(px0, py0, mx, my);
                area.quadTo(px0, py0, mx, my);
            }
            px0 = x; py0 = y;
        }
        path.lineTo(px0, py0);
        area.lineTo(px0, py0);
        area.lineTo(w, h);
        area.close();
        canvas.drawPath(area, fill);
        canvas.drawPath(path, halo);
        canvas.drawPath(path, line);
    }
}
