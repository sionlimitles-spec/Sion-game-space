package com.sion.gamespace;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;

/**
 * Shell root yang tetap terbuka. Dua instance dipakai: 0 untuk aksi pengguna, 1 untuk
 * pemantauan (supaya aksi tidak menunggu pengukuran).
 */
final class RootShell {
    private static final RootShell[] POOL = new RootShell[2];

    private Process proc;
    private DataOutputStream out;
    private BufferedReader in;
    private boolean root;

    static synchronized RootShell get(int slot) {
        if (POOL[slot] == null) POOL[slot] = new RootShell();
        return POOL[slot];
    }

    private RootShell() {
        open();
    }

    private void open() {
        close();
        try {
            proc = new ProcessBuilder("su").redirectErrorStream(true).start();
            out = new DataOutputStream(proc.getOutputStream());
            in = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            root = false;
            String r = rawExec("id -u", 8000);
            root = r != null && r.trim().equals("0");
        } catch (Exception e) {
            root = false;
        }
    }

    private void close() {
        try { if (out != null) out.close(); } catch (Exception ignored) { }
        try { if (proc != null) proc.destroy(); } catch (Exception ignored) { }
        proc = null;
        out = null;
        in = null;
    }

    synchronized boolean isRoot() {
        return root;
    }

    /** Buka ulang shell dan periksa akses root lagi. */
    synchronized boolean recheck() {
        open();
        return root;
    }

    /** Jalankan perintah, kembalikan keluarannya. Aman dipanggil dari thread latar. */
    synchronized String exec(String cmd) {
        return exec(cmd, 15000);
    }

    synchronized String exec(String cmd, long timeoutMs) {
        if (proc == null) open();
        String r = rawExec(cmd, timeoutMs);
        if (r == null) {
            // shell mati atau macet: buka ulang sekali lalu coba lagi
            open();
            r = rawExec(cmd, timeoutMs);
        }
        return r == null ? "" : r;
    }

    private String rawExec(String cmd, long timeoutMs) {
        if (proc == null || out == null || in == null) return null;
        final Process p = proc;
        final long end = System.currentTimeMillis() + timeoutMs;
        Thread watchdog = new Thread(new Runnable() {
            @Override public void run() {
                try {
                    Thread.sleep(timeoutMs);
                    p.destroy();
                } catch (InterruptedException ignored) { }
            }
        });
        watchdog.setDaemon(true);
        watchdog.start();
        try {
            String tag = "__GS_END_" + System.nanoTime() + "__";
            String line = "{ " + cmd + "\n} </dev/null\nprintf '\\n%s\\n' " + tag + "\n";
            out.write(line.getBytes("UTF-8"));
            out.flush();
            StringBuilder sb = new StringBuilder();
            String l;
            while ((l = in.readLine()) != null) {
                if (l.equals(tag)) {
                    watchdog.interrupt();
                    return sb.toString().trim();
                }
                sb.append(l).append('\n');
                if (System.currentTimeMillis() > end + 2000) break;
            }
            watchdog.interrupt();
            return null;
        } catch (Exception e) {
            watchdog.interrupt();
            return null;
        }
    }
}
