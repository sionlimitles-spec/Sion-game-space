package com.sion.gamespace;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.OvershootInterpolator;

/** Pemilih 3 mode: Hemat, Seimbang, Performa. Sorot meluncur dan berganti warna mengikuti mode. */
final class ModeBar extends View {
    interface Listener { void onMode(String id); }

    static final String[] IDS = {"chill", "balance", "turbo"};
    private static final String[] NAMES = {"Hemat", "Seimbang", "Performa"};

    private int index = 1;
    private float pos = 1f;
    private Listener listener;
    private ValueAnimator anim;
    private Theme t = Theme.SEIMBANG;
    private final float u;
    private final Paint back = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hi = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ink = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();

    ModeBar(Context c, float u) {
        super(c);
        this.u = u;
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setTextSize(u * 21);
        txt.setTypeface(Typeface.DEFAULT_BOLD);
        ink.setStrokeWidth(Math.max(1.5f, u * 2.4f));
        ink.setStrokeCap(Paint.Cap.ROUND);
        ink.setStrokeJoin(Paint.Join.ROUND);
        setClickable(true);
    }

    void setListener(Listener l) { listener = l; }

    void setTheme(Theme th) { t = th; invalidate(); }

    String current() { return IDS[index]; }

    void select(String id, boolean animate) {
        int i = 1;
        for (int k = 0; k < IDS.length; k++) if (IDS[k].equals(id)) i = k;
        index = i;
        if (anim != null) anim.cancel();
        if (!animate) { pos = i; invalidate(); return; }
        anim = ValueAnimator.ofFloat(pos, i);
        anim.setDuration(420);
        anim.setInterpolator(new OvershootInterpolator(1.1f));
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) { pos = (Float) a.getAnimatedValue(); invalidate(); }
        });
        anim.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_UP) {
            int i = Math.max(0, Math.min(2, (int) (e.getX() / (getWidth() / 3f))));
            if (i != index) {
                select(IDS[i], true);
                performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK);
                if (listener != null) listener.onMode(IDS[i]);
            }
        }
        return true;
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth();
        int h = getHeight();
        float rad = h / 2f;
        r.set(1, 1, w - 1, h - 1);
        back.setStyle(Paint.Style.FILL);
        back.setColor(0x44000000);
        c.drawRoundRect(r, rad, rad, back);
        back.setStyle(Paint.Style.STROKE);
        back.setStrokeWidth(Math.max(1f, u * 1.4f));
        back.setColor((0x66 << 24) | (t.a2 & 0xFFFFFF));
        c.drawRoundRect(r, rad, rad, back);
        float seg = w / 3f;
        float pad = u * 4;
        r.set(pos * seg + pad, pad, (pos + 1) * seg - pad, h - pad);
        hi.setShader(new LinearGradient(r.left, 0, r.right, 0, t.a1, t.a2, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, hi);
        for (int i = 0; i < 3; i++) {
            float near = Math.max(0f, 1f - Math.abs(pos - i));
            txt.setColor(blend(0xFFB9C4D8, t.on, near));
            float cx = seg * i + seg / 2f;
            float ty = h / 2f + txt.getTextSize() * 0.35f;
            if (near > 0.5f) {
                // ikon kecil di depan nama pada mode terpilih
                float tw = txt.measureText(NAMES[i]);
                float s = h * 0.22f;
                ink.setColor(t.on);
                ink.setAlpha((int) (255 * Math.min(1f, (near - 0.5f) * 2f)));
                Icons.modeIcon(c, IDS[i], cx - tw / 2f - s * 1.1f, h / 2f, s, ink);
                c.drawText(NAMES[i], cx + s * 0.9f, ty, txt);
            } else {
                c.drawText(NAMES[i], cx, ty, txt);
            }
        }
    }

    private static int blend(int a, int b, float t) {
        int rr = (int) (((a >> 16) & 255) + ((((b >> 16) & 255) - ((a >> 16) & 255)) * t));
        int gg = (int) (((a >> 8) & 255) + ((((b >> 8) & 255) - ((a >> 8) & 255)) * t));
        int bl = (int) ((a & 255) + (((b & 255) - (a & 255)) * t));
        return 0xFF000000 | (rr << 16) | (gg << 8) | bl;
    }
}
