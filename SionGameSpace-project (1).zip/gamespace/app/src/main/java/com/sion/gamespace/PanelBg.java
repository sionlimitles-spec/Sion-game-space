package com.sion.gamespace;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Latar kartu panel: kaca gelap, bingkai neon berlapis, garis aksen miring di pojok. */
final class PanelBg extends Drawable {
    private final float rad;
    private final float px;
    private Theme t = Theme.SEIMBANG;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path p = new Path();

    PanelBg(float radiusPx, float onePx) {
        rad = radiusPx;
        px = onePx;
        line.setStyle(Paint.Style.STROKE);
    }

    void setTheme(Theme th) {
        t = th;
        invalidateSelf();
    }

    @Override
    public void draw(Canvas c) {
        int w = getBounds().width();
        int h = getBounds().height();
        float m = px * 6;
        r.set(m, m, w - m, h - m);
        fill.setShader(new LinearGradient(0, 0, w * 0.6f, h, t.bg1, t.bg2, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, fill);
        // cahaya luar berlapis
        int[] ws = {10, 6, 3};
        int[] al = {0x14, 0x24, 0x44};
        for (int i = 0; i < ws.length; i++) {
            line.setStrokeWidth(px * ws[i]);
            line.setColor((al[i] << 24) | (t.a2 & 0xFFFFFF));
            c.drawRoundRect(r, rad, rad, line);
        }
        line.setStrokeWidth(px * 1.6f);
        line.setShader(new LinearGradient(0, 0, w, h, t.a3, t.a1, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, line);
        line.setShader(null);
        // kilap atas-kiri
        fill.setShader(new LinearGradient(0, 0, w * 0.7f, h * 0.35f, 0x24FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, fill);
        fill.setShader(null);
        // garis aksen miring (pojok kiri atas)
        fill.setColor(t.a3);
        fill.setAlpha(0xB0);
        for (int i = 0; i < 2; i++) {
            float x = m + px * (16 + i * 13), y = m + px * 52;
            p.reset();
            p.moveTo(x, y); p.lineTo(x + px * 7, y - px * 6); p.lineTo(x + px * 7 + px * 5, y - px * 6);
            p.lineTo(x + px * 5, y); p.close();
            c.drawPath(p, fill);
        }
    }

    @Override public void setAlpha(int a) { }
    @Override public void setColorFilter(ColorFilter cf) { }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
