package com.sion.gamespace;

/** Satu pengukuran dari skrip root. */
final class Metrics {
    int fps;
    int tempCpu;
    int tempBat;
    int bat = -1;
    int curMa;
    int ramUsed;
    int ramFreeMb;
    int gpu = -1;
    int ping = -1;
    float cpuLoad = -1;
    long cpuIdle;
    long cpuTotal;
    float[] ft = new float[0];

    static Metrics parse(String out) {
        Metrics m = new Metrics();
        if (out == null) return m;
        for (String line : out.split("\n")) {
            int i = line.indexOf('=');
            if (i <= 0) continue;
            String k = line.substring(0, i).trim();
            String v = line.substring(i + 1).trim();
            try {
                switch (k) {
                    case "fps": m.fps = Integer.parseInt(v); break;
                    case "temp_cpu": m.tempCpu = Integer.parseInt(v); break;
                    case "temp_bat": m.tempBat = Integer.parseInt(v); break;
                    case "bat": m.bat = Integer.parseInt(v); break;
                    case "cur_ma": m.curMa = Integer.parseInt(v); break;
                    case "ram_used": m.ramUsed = Integer.parseInt(v); break;
                    case "ram_free_mb": m.ramFreeMb = Integer.parseInt(v); break;
                    case "gpu": m.gpu = v.isEmpty() ? -1 : Integer.parseInt(v); break;
                    case "cpu_idle": m.cpuIdle = Long.parseLong(v); break;
                    case "cpu_total": m.cpuTotal = Long.parseLong(v); break;
                    case "ft": {
                        String[] parts = v.split(",");
                        float[] f = new float[parts.length];
                        int n = 0;
                        for (String p : parts) {
                            if (p.isEmpty()) continue;
                            f[n++] = Float.parseFloat(p);
                        }
                        m.ft = java.util.Arrays.copyOf(f, n);
                        break;
                    }
                    default: break;
                }
            } catch (NumberFormatException ignored) { }
        }
        return m;
    }

    /** Suhu tertinggi yang tersedia. */
    int temp() {
        return Math.max(tempCpu, tempBat);
    }
}
