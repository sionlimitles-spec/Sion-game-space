package com.sion.gamespace;

import android.graphics.Color;

/** Warna per mode: Hemat = putih/abu/hitam, Seimbang = biru, Performa = merah. */
final class Theme {
    final int a1, a2, a3;     // aksen gelap, tengah, terang
    final int on;             // warna teks di atas aksen
    final int bg1, bg2;       // gradasi latar kartu
    final int ink;            // warna ikon di atas kaca
    final float hue;          // putaran warna gambar karakter (derajat)
    final float sat;          // saturasi gambar karakter

    private Theme(int a1, int a2, int a3, int on, int bg1, int bg2, int ink, float hue, float sat) {
        this.a1 = a1; this.a2 = a2; this.a3 = a3; this.on = on;
        this.bg1 = bg1; this.bg2 = bg2; this.ink = ink; this.hue = hue; this.sat = sat;
    }

    static final Theme HEMAT = new Theme(0xFF8E96A3, 0xFFD3D8DF, 0xFFFFFFFF, 0xFF0B0D10,
            0xF0262A31, 0xF00A0B0E, 0xFFE8ECF1, 0f, 0f);
    static final Theme SEIMBANG = new Theme(0xFF2459FF, 0xFF3EA6FF, 0xFF7FE3FF, 0xFFFFFFFF,
            0xEC1B2D5C, 0xF00A1530, 0xFFD6E6FF, 0f, 1f);
    static final Theme PERFORMA = new Theme(0xFFD81F2A, 0xFFFF4B4B, 0xFFFF9C8F, 0xFFFFFFFF,
            0xEC4A1219, 0xF0160609, 0xFFFFDCD8, 148f, 1.1f);

    static Theme of(String mode) {
        if ("chill".equals(mode)) return HEMAT;
        if ("turbo".equals(mode) || "tourney".equals(mode)) return PERFORMA;
        return SEIMBANG;
    }

    private static int mix(int a, int b, float t) {
        int al = (int) (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * t);
        int r = (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.argb(al, r, g, bl);
    }

    /** Campuran dua tema untuk animasi perpindahan mode. */
    static Theme lerp(Theme x, Theme y, float t) {
        if (t <= 0f) return x;
        if (t >= 1f) return y;
        return new Theme(mix(x.a1, y.a1, t), mix(x.a2, y.a2, t), mix(x.a3, y.a3, t), mix(x.on, y.on, t),
                mix(x.bg1, y.bg1, t), mix(x.bg2, y.bg2, t), mix(x.ink, y.ink, t),
                x.hue + (y.hue - x.hue) * t, x.sat + (y.sat - x.sat) * t);
    }
}
