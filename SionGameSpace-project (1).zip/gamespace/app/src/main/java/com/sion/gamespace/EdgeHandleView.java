package com.sion.gamespace;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Build;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateDecelerateInterpolator;

import java.util.ArrayList;
import java.util.List;

/**
 * Gagang tepi layar. Seret ke tengah untuk membuka panel.
 * Mode "edge": sliver tipis menempel di tepi. Mode "tab": tab kecil agak masuk dari tepi
 * (aman dari gestur kembali di ROM yang tetap memakan tepi).
 */
final class EdgeHandleView extends View {
    interface Listener {
        void onDragStart();
        void onDrag(float progress);      // 0..1
        void onDragEnd(boolean open);
        void onTap();
    }

    private final boolean right;
    private final boolean stealth;
    private Listener listener;
    private float breath;            // 0..1 berdenyut
    private float awake = 1f;        // 1 = terang, turun saat idle
    private ValueAnimator pulse;
    private ValueAnimator dimmer;
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint core = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private float downX, downY;
    private boolean dragging;
    private boolean decided;
    private VelocityTracker vt;
    private final int slop;
    private float travel;            // px untuk 100%
    private int glowRgb = 0x3EA6FF;
    private int coreRgb = 0x7FE3FF;

    EdgeHandleView(Context c, boolean right, boolean stealth, float travelPx) {
        super(c);
        this.right = right;
        this.stealth = stealth;
        this.travel = Math.max(1f, travelPx);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
    }

    void setListener(Listener l) { listener = l; }

    void setTheme(Theme t) {
        glowRgb = t.a2 & 0xFFFFFF;
        coreRgb = t.a3 & 0xFFFFFF;
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!stealth) {
            pulse = ValueAnimator.ofFloat(0f, 1f);
            pulse.setDuration(2400);
            pulse.setRepeatCount(ValueAnimator.INFINITE);
            pulse.setRepeatMode(ValueAnimator.REVERSE);
            pulse.setInterpolator(new AccelerateDecelerateInterpolator());
            pulse.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator a) { breath = (Float) a.getAnimatedValue(); invalidate(); }
            });
            pulse.start();
            scheduleDim();
        }
        updateExclusion();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (pulse != null) pulse.cancel();
        if (dimmer != null) dimmer.cancel();
        removeCallbacks(dimTask);
    }

    private final Runnable dimTask = new Runnable() {
        @Override public void run() { animateAwake(0.35f); }
    };

    private void scheduleDim() {
        removeCallbacks(dimTask);
        postDelayed(dimTask, 4000);
    }

    private void animateAwake(float to) {
        if (dimmer != null) dimmer.cancel();
        dimmer = ValueAnimator.ofFloat(awake, to);
        dimmer.setDuration(450);
        dimmer.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) { awake = (Float) a.getAnimatedValue(); invalidate(); }
        });
        dimmer.start();
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
        updateExclusion();
    }

    private void updateExclusion() {
        if (Build.VERSION.SDK_INT >= 29) {
            List<Rect> list = new ArrayList<Rect>();
            list.add(new Rect(0, 0, getWidth(), getHeight()));
            setSystemGestureExclusionRects(list);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getRawX();
                downY = e.getRawY();
                dragging = false;
                decided = false;
                vt = VelocityTracker.obtain();
                vt.addMovement(e);
                removeCallbacks(dimTask);
                animateAwake(1f);
                getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            case MotionEvent.ACTION_MOVE: {
                if (vt != null) vt.addMovement(e);
                float dx = (right ? downX - e.getRawX() : e.getRawX() - downX);
                float dy = Math.abs(e.getRawY() - downY);
                if (!decided && (Math.abs(dx) > slop || dy > slop)) {
                    decided = true;
                    dragging = dx > 0 && dx >= dy * 0.6f;
                    if (dragging && listener != null) listener.onDragStart();
                }
                if (dragging && listener != null) listener.onDrag(Math.max(0f, Math.min(1f, dx / travel)));
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                float dx = (right ? downX - e.getRawX() : e.getRawX() - downX);
                float vel = 0;
                if (vt != null) {
                    vt.addMovement(e);
                    vt.computeCurrentVelocity(1000);
                    vel = right ? -vt.getXVelocity() : vt.getXVelocity();
                    vt.recycle();
                    vt = null;
                }
                if (dragging) {
                    boolean open = e.getActionMasked() == MotionEvent.ACTION_UP
                            && (dx / travel > 0.4f || vel > 900f);
                    if (listener != null) listener.onDragEnd(open);
                } else if (e.getActionMasked() == MotionEvent.ACTION_UP && !decided) {
                    if (listener != null) listener.onTap();
                }
                dragging = false;
                if (!stealth) scheduleDim();
                return true;
            }
            default:
                return true;
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        if (stealth) return;
        int w = getWidth();
        int h = getHeight();
        float a = awake * (0.7f + 0.3f * breath);
        int alpha = (int) (255 * a);
        float edgeX = right ? w : 0f;
        float lineW = Ui.dp(getContext(), 3);
        // cahaya lembut ke dalam
        glow.setShader(new LinearGradient(edgeX, 0, right ? 0f : w, 0,
                (alpha / 2 << 24) | glowRgb, glowRgb, Shader.TileMode.CLAMP));
        rect.set(0, 0, w, h);
        c.drawRoundRect(rect, w / 2f, w / 2f, glow);
        // garis inti
        core.setShader(new LinearGradient(0, 0, 0, h,
                new int[]{coreRgb, (alpha << 24) | coreRgb, coreRgb}, null, Shader.TileMode.CLAMP));
        float x0 = right ? w - lineW : 0f;
        rect.set(x0, h * 0.04f, x0 + lineW, h * 0.96f);
        c.drawRoundRect(rect, lineW, lineW, core);
    }
}
