package com.sion.gamespace;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Menyalakan pemantau game setelah perangkat hidup, bila diaktifkan. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (i == null || !Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) return;
        Store s = new Store(c);
        if (!s.cfg().optBoolean("autoStart", true) || s.games().length() == 0) return;
        try {
            c.startForegroundService(new Intent(c, GameService.class).setAction(GameService.ACT_START));
        } catch (RuntimeException ignored) { }
    }
}
