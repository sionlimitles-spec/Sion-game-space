package com.sion.gamespace;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** Tab « di sisi dalam panel. Ketuk atau seret ke tepi untuk menutup. */
final class ChevronTab extends View {
    interface Listener {
        void onStart();
        void onDrag(float dxToEdge);   // px, positif menuju tepi
        void onEnd(boolean close, float velocity);
    }

    private final boolean panelRight;
    private final float u;
    private Theme t = Theme.SEIMBANG;
    private Listener l;
    private float downX;
    private boolean drag;
    private android.view.VelocityTracker vt;
    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ink = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();

    ChevronTab(Context c, boolean panelRight, float u) {
        super(c);
        this.panelRight = panelRight;
        this.u = u;
        ink.setStrokeWidth(Math.max(2f, u * 3.2f));
        ink.setStrokeCap(Paint.Cap.ROUND);
        ink.setStrokeJoin(Paint.Join.ROUND);
        setClickable(true);
    }

    void setListener(Listener x) { l = x; }

    void setTheme(Theme th) { t = th; invalidate(); }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getRawX(); drag = false;
                vt = android.view.VelocityTracker.obtain(); vt.addMovement(e);
                return true;
            case MotionEvent.ACTION_MOVE: {
                if (vt != null) vt.addMovement(e);
                float dx = panelRight ? e.getRawX() - downX : downX - e.getRawX();
                if (!drag && Math.abs(dx) > u * 8) { drag = true; if (l != null) l.onStart(); }
                if (drag && l != null) l.onDrag(Math.max(0f, dx));
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                float vel = 0;
                if (vt != null) { vt.addMovement(e); vt.computeCurrentVelocity(1000); vel = panelRight ? vt.getXVelocity() : -vt.getXVelocity(); vt.recycle(); vt = null; }
                float dx = panelRight ? e.getRawX() - downX : downX - e.getRawX();
                if (drag) { if (l != null) l.onEnd(e.getActionMasked() == MotionEvent.ACTION_UP && (dx > u * 120 || vel > 900), vel); }
                else if (e.getActionMasked() == MotionEvent.ACTION_UP && l != null) { l.onStart(); l.onEnd(true, 0); }
                drag = false;
                return true;
            }
            default: return true;
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        r.set(1, 1, w - 1, h - 1);
        float rad = w * 0.5f;
        bg.setStyle(Paint.Style.FILL);
        bg.setColor(t.bg2);
        c.drawRoundRect(r, rad, rad, bg);
        bg.setStyle(Paint.Style.STROKE);
        bg.setStrokeWidth(Math.max(1f, u * 1.6f));
        bg.setColor(t.a2);
        c.drawRoundRect(r, rad, rad, bg);
        ink.setColor(t.a3);
        // « di panel kanan menunjuk ke kanan (menutup ke tepi), » di panel kiri
        int dir = panelRight ? 1 : -1;
        float s = w * 0.22f;
        Icons.chevron(c, w / 2f - dir * s * 0.55f, h / 2f, s, ink, dir);
        Icons.chevron(c, w / 2f + dir * s * 0.55f, h / 2f, s, ink, dir);
    }
}
