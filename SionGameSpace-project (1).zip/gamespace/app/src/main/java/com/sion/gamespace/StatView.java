package com.sion.gamespace;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** Satu kotak data kecil: ikon, nama, angka. */
final class StatView extends View {
    static final int THERMO = 0, SIGNAL = 1, BATT = 2, CHIP = 3;
    private final int kind;
    private final String label;
    private String value = "--";
    private boolean warn;
    private float level = 0.7f;
    private Theme t = Theme.SEIMBANG;
    private final float u;
    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ink = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tl = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tv = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();

    StatView(Context c, int kind, String label, float u) {
        super(c);
        this.kind = kind;
        this.label = label;
        this.u = u;
        ink.setStrokeWidth(Math.max(1.5f, u * 2.4f));
        ink.setStrokeCap(Paint.Cap.ROUND);
        ink.setStrokeJoin(Paint.Join.ROUND);
        tl.setTextAlign(Paint.Align.CENTER);
        tl.setTextSize(u * 19);
        tv.setTextAlign(Paint.Align.CENTER);
        tv.setTextSize(u * 27);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
    }

    void setTheme(Theme th) { t = th; invalidate(); }

    void set(String v, boolean warn, float level) {
        if (v.equals(value) && warn == this.warn && level == this.level) return;
        value = v; this.warn = warn; this.level = level;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        float rad = u * 18;
        r.set(1, 1, w - 1, h - 1);
        bg.setStyle(Paint.Style.FILL);
        bg.setColor(0x38000000);
        c.drawRoundRect(r, rad, rad, bg);
        bg.setStyle(Paint.Style.STROKE);
        bg.setStrokeWidth(Math.max(1f, u * 1.4f));
        bg.setColor((0x70 << 24) | (t.a2 & 0xFFFFFF));
        c.drawRoundRect(r, rad, rad, bg);
        int col = warn ? 0xFFFFB547 : t.a3;
        ink.setColor(col);
        float cx = w / 2f, cy = h * 0.27f, s = u * 14;
        if (kind == THERMO) Icons.thermo(c, cx - s * 0.2f, cy, s, ink);
        else if (kind == SIGNAL) Icons.signal(c, cx, cy, s, ink);
        else if (kind == BATT) Icons.battery(c, cx, cy, s, ink, level);
        else Icons.chip(c, cx, cy, s, ink);
        tl.setColor(0xFFD7E2F5);
        c.drawText(label, cx, h * 0.55f, tl);
        tv.setColor(warn ? 0xFFFFB547 : 0xFFFFFFFF);
        c.drawText(value, cx, h * 0.86f, tv);
    }
}
