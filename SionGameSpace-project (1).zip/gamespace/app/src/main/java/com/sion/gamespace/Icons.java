package com.sion.gamespace;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

/** Ikon garis sederhana yang digambar langsung di kanvas. Pusat (x,y), ukuran s. */
final class Icons {
    private static final Path P = new Path();
    private static final RectF R = new RectF();

    private Icons() { }

    static void thermo(Canvas c, float x, float y, float s, Paint ink) {
        Paint.Style old = ink.getStyle();
        ink.setStyle(Paint.Style.STROKE);
        R.set(x - s * 0.28f, y - s * 1.0f, x + s * 0.28f, y + s * 0.45f);
        c.drawRoundRect(R, s * 0.28f, s * 0.28f, ink);
        c.drawCircle(x, y + s * 0.62f, s * 0.5f, ink);
        c.drawLine(x, y - s * 0.1f, x, y + s * 0.55f, ink);
        c.drawLine(x + s * 0.55f, y - s * 0.75f, x + s * 0.85f, y - s * 0.75f, ink);
        c.drawLine(x + s * 0.55f, y - s * 0.4f, x + s * 0.85f, y - s * 0.4f, ink);
        ink.setStyle(old);
    }

    static void signal(Canvas c, float x, float y, float s, Paint ink) {
        Paint.Style old = ink.getStyle();
        ink.setStyle(Paint.Style.FILL);
        float bw = s * 0.34f;
        for (int i = 0; i < 4; i++) {
            float h = s * (0.5f + 0.4f * i);
            float bx = x - s * 0.95f + i * (bw + s * 0.17f);
            R.set(bx, y + s * 0.9f - h, bx + bw, y + s * 0.9f);
            c.drawRoundRect(R, bw * 0.3f, bw * 0.3f, ink);
        }
        ink.setStyle(old);
    }

    static void battery(Canvas c, float x, float y, float s, Paint ink, float level) {
        Paint.Style old = ink.getStyle();
        ink.setStyle(Paint.Style.STROKE);
        R.set(x - s * 0.55f, y - s * 0.85f, x + s * 0.55f, y + s * 0.95f);
        c.drawRoundRect(R, s * 0.18f, s * 0.18f, ink);
        c.drawLine(x - s * 0.2f, y - s * 1.08f, x + s * 0.2f, y - s * 1.08f, ink);
        ink.setStyle(Paint.Style.FILL);
        float top = y + s * 0.8f - (s * 1.4f) * Math.max(0.08f, Math.min(1f, level));
        R.set(x - s * 0.35f, top, x + s * 0.35f, y + s * 0.8f);
        c.drawRoundRect(R, s * 0.1f, s * 0.1f, ink);
        ink.setStyle(old);
    }

    static void chip(Canvas c, float x, float y, float s, Paint ink) {
        Paint.Style old = ink.getStyle();
        ink.setStyle(Paint.Style.STROKE);
        R.set(x - s * 0.7f, y - s * 0.7f, x + s * 0.7f, y + s * 0.7f);
        c.drawRoundRect(R, s * 0.2f, s * 0.2f, ink);
        R.set(x - s * 0.28f, y - s * 0.28f, x + s * 0.28f, y + s * 0.28f);
        c.drawRect(R, ink);
        for (int i = -1; i <= 1; i += 2) {
            for (int k = -1; k <= 1; k += 2) {
                c.drawLine(x + k * s * 0.3f, y + i * s * 0.7f, x + k * s * 0.3f, y + i * s * 1.05f, ink);
                c.drawLine(x + i * s * 0.7f, y + k * s * 0.3f, x + i * s * 1.05f, y + k * s * 0.3f, ink);
            }
        }
        ink.setStyle(old);
    }

    static void rocket(Canvas c, float x, float y, float s, Paint ink) {
        Paint.Style old = ink.getStyle();
        ink.setStyle(Paint.Style.STROKE);
        c.save();
        c.rotate(45f, x, y);
        P.reset();
        P.moveTo(x, y - s * 1.15f);
        P.quadTo(x + s * 0.62f, y - s * 0.45f, x + s * 0.45f, y + s * 0.55f);
        P.lineTo(x - s * 0.45f, y + s * 0.55f);
        P.quadTo(x - s * 0.62f, y - s * 0.45f, x, y - s * 1.15f);
        c.drawPath(P, ink);
        c.drawCircle(x, y - s * 0.3f, s * 0.2f, ink);
        P.reset();
        P.moveTo(x - s * 0.45f, y + s * 0.15f); P.lineTo(x - s * 0.85f, y + s * 0.8f); P.lineTo(x - s * 0.45f, y + s * 0.55f);
        P.moveTo(x + s * 0.45f, y + s * 0.15f); P.lineTo(x + s * 0.85f, y + s * 0.8f); P.lineTo(x + s * 0.45f, y + s * 0.55f);
        c.drawPath(P, ink);
        c.drawLine(x, y + s * 0.7f, x, y + s * 1.1f, ink);
        c.restore();
        ink.setStyle(old);
    }

    static void leaf(Canvas c, float x, float y, float s, Paint ink) {
        Paint.Style old = ink.getStyle();
        ink.setStyle(Paint.Style.STROKE);
        P.reset();
        P.moveTo(x - s * 0.85f, y + s * 0.85f);
        P.quadTo(x - s * 1.0f, y - s * 0.9f, x + s * 0.95f, y - s * 0.95f);
        P.quadTo(x + s * 1.0f, y + s * 0.85f, x - s * 0.85f, y + s * 0.85f);
        c.drawPath(P, ink);
        c.drawLine(x - s * 0.85f, y + s * 0.85f, x + s * 0.25f, y - s * 0.2f, ink);
        ink.setStyle(old);
    }

    static void balance(Canvas c, float x, float y, float s, Paint ink) {
        Paint.Style old = ink.getStyle();
        ink.setStyle(Paint.Style.STROKE);
        c.drawCircle(x, y, s * 0.9f, ink);
        ink.setStyle(Paint.Style.FILL);
        R.set(x - s * 0.9f, y - s * 0.9f, x + s * 0.9f, y + s * 0.9f);
        c.drawArc(R, 90f, 180f, true, ink);
        ink.setStyle(old);
    }

    static void bolt(Canvas c, float x, float y, float s, Paint ink) {
        Paint.Style old = ink.getStyle();
        ink.setStyle(Paint.Style.FILL);
        P.reset();
        P.moveTo(x + s * 0.2f, y - s * 1.05f);
        P.lineTo(x - s * 0.6f, y + s * 0.2f);
        P.lineTo(x - s * 0.05f, y + s * 0.2f);
        P.lineTo(x - s * 0.2f, y + s * 1.05f);
        P.lineTo(x + s * 0.62f, y - s * 0.25f);
        P.lineTo(x + s * 0.05f, y - s * 0.25f);
        P.close();
        c.drawPath(P, ink);
        ink.setStyle(old);
    }

    /** dir = +1 menghadap kanan, -1 menghadap kiri. */
    static void chevron(Canvas c, float x, float y, float s, Paint ink, int dir) {
        Paint.Style old = ink.getStyle();
        ink.setStyle(Paint.Style.STROKE);
        c.drawLine(x - dir * s * 0.4f, y - s * 0.75f, x + dir * s * 0.4f, y, ink);
        c.drawLine(x + dir * s * 0.4f, y, x - dir * s * 0.4f, y + s * 0.75f, ink);
        ink.setStyle(old);
    }

    static void cross(Canvas c, float x, float y, float s, Paint ink) {
        Paint.Style old = ink.getStyle();
        ink.setStyle(Paint.Style.STROKE);
        c.drawLine(x - s * 0.6f, y - s * 0.6f, x + s * 0.6f, y + s * 0.6f, ink);
        c.drawLine(x + s * 0.6f, y - s * 0.6f, x - s * 0.6f, y + s * 0.6f, ink);
        ink.setStyle(old);
    }

    static void modeIcon(Canvas c, String mode, float x, float y, float s, Paint ink) {
        if ("chill".equals(mode)) leaf(c, x, y, s, ink);
        else if ("turbo".equals(mode) || "tourney".equals(mode)) rocket(c, x, y, s, ink);
        else balance(c, x, y, s, ink);
    }
}
