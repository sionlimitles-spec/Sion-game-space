package com.sion.gamespace;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

/** Logo "S" miring dengan cahaya aksen. */
final class LogoView extends View {
    private Theme t = Theme.SEIMBANG;
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);

    LogoView(Context c) {
        super(c);
        txt.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC));
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setTextSkewX(-0.22f);
    }

    void setTheme(Theme th) { t = th; invalidate(); }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f;
        glow.setShader(new android.graphics.RadialGradient(cx, cy, w * 0.55f,
                new int[]{(0x66 << 24) | (t.a2 & 0xFFFFFF), 0x00000000}, null, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, w * 0.55f, glow);
        txt.setTextSize(h * 0.95f);
        txt.setShader(new LinearGradient(0, 0, w, h, t.a3, t.a1, Shader.TileMode.CLAMP));
        c.drawText("S", cx, cy + h * 0.33f, txt);
    }
}
