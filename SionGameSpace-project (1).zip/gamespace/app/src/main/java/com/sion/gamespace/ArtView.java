package com.sion.gamespace;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

import java.io.IOException;
import java.io.InputStream;

/** Gambar karakter di kartu FPS. Warnanya ikut mode lewat matriks warna. */
final class ArtView extends View {
    private static Bitmap cache;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Rect src = new Rect();
    private final Rect dst = new Rect();

    ArtView(Context c) {
        super(c);
        if (cache == null) {
            InputStream in = null;
            try {
                in = c.getAssets().open("panel_art.png");
                cache = BitmapFactory.decodeStream(in);
            } catch (IOException ignored) {
            } finally {
                try { if (in != null) in.close(); } catch (IOException ignored) { }
            }
        }
        setTheme(Theme.SEIMBANG);
    }

    void setTheme(Theme t) {
        ColorMatrix sat = new ColorMatrix();
        sat.setSaturation(t.sat);
        ColorMatrix m = new ColorMatrix();
        double a = Math.toRadians(t.hue);
        float cs = (float) Math.cos(a), sn = (float) Math.sin(a);
        // putar rona (hue) di ruang RGB
        m.set(new float[]{
                0.213f + cs * 0.787f - sn * 0.213f, 0.715f - cs * 0.715f - sn * 0.715f, 0.072f - cs * 0.072f + sn * 0.928f, 0, 0,
                0.213f - cs * 0.213f + sn * 0.143f, 0.715f + cs * 0.285f + sn * 0.140f, 0.072f - cs * 0.072f - sn * 0.283f, 0, 0,
                0.213f - cs * 0.213f - sn * 0.787f, 0.715f - cs * 0.715f + sn * 0.715f, 0.072f + cs * 0.928f + sn * 0.072f, 0, 0,
                0, 0, 0, 1, 0});
        m.postConcat(sat);
        p.setColorFilter(new ColorMatrixColorFilter(m));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (cache == null) return;
        int w = getWidth(), h = getHeight();
        float br = cache.getWidth() / (float) cache.getHeight();
        int dh = h;
        int dw = Math.round(dh * br);
        if (dw < w) { dw = w; dh = Math.round(dw / br); }
        src.set(0, 0, cache.getWidth(), cache.getHeight());
        dst.set(w - dw, (h - dh) / 2, w, (h - dh) / 2 + dh);
        c.drawBitmap(cache, src, dst, p);
    }
}
