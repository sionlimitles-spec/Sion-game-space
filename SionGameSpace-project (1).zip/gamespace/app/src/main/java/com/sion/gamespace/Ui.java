package com.sion.gamespace;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;

/** Warna dan bentuk bersama untuk jendela melayang. */
final class Ui {
    static final int BLUE = 0xFF2459FF;
    static final int SKY = 0xFF3EA6FF;
    static final int CYAN = 0xFF7FE3FF;
    static final int TEXT = 0xFFF2F7FF;
    static final int MUTE = 0xFF93A6C4;
    static final int OK = 0xFF3DDC97;
    static final int WARN = 0xFFFFB547;

    private Ui() { }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    /** Kartu kaca gelap dengan tepi bercahaya. */
    static GradientDrawable glass(Context c, float radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xEC1B2D5C, 0xF00A1530});
        g.setCornerRadius(dp(c, radiusDp));
        g.setStroke(dp(c, 1), 0x66BFDFFF);
        return g;
    }

    static GradientDrawable glassRadii(Context c, float radiusDp, boolean roundLeft) {
        GradientDrawable g = glass(c, radiusDp);
        float r = dp(c, radiusDp);
        float[] radii = roundLeft
                ? new float[]{r, r, 0, 0, 0, 0, r, r}
                : new float[]{0, 0, r, r, r, r, 0, 0};
        // kartu mengambang: semua sudut tetap bulat
        radii = new float[]{r, r, r, r, r, r, r, r};
        g.setCornerRadii(radii);
        return g;
    }

    static GradientDrawable inner(Context c, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(0x26FFFFFF);
        g.setCornerRadius(dp(c, radiusDp));
        g.setStroke(dp(c, 1), 0x22FFFFFF);
        return g;
    }

    static GradientDrawable pill(Context c, int color, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, 40));
        g.setStroke(dp(c, 1), strokeColor);
        return g;
    }
}
