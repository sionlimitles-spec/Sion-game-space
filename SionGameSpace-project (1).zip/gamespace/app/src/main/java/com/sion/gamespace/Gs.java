package com.sion.gamespace;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Pembantu untuk menjalankan skrip root gs.sh. */
final class Gs {
    static final String PKG = "com.sion.gamespace";
    static final String DIR = "/data/local/tmp/gamespace";
    static final String SCRIPT = DIR + "/gs.sh";

    private static volatile boolean ready;

    private Gs() { }

    static synchronized void ensure(Context c) {
        if (ready) return;
        File f = new File(c.getFilesDir(), "gs.sh");
        InputStream in = null;
        FileOutputStream out = null;
        try {
            in = c.getAssets().open("gs.sh");
            out = new FileOutputStream(f);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } catch (IOException ignored) {
        } finally {
            try { if (in != null) in.close(); } catch (IOException ignored) { }
            try { if (out != null) out.close(); } catch (IOException ignored) { }
        }
        RootShell sh = RootShell.get(0);
        sh.exec("mkdir -p " + DIR + " && cp '" + f.getAbsolutePath() + "' " + SCRIPT + " && chmod 755 " + SCRIPT);
        ready = "1".equals(sh.exec("[ -s " + SCRIPT + " ] && echo 1"));
    }

    /** Jalankan "gs.sh <args>" lewat shell root pada slot tertentu. */
    static String sh(Context c, int slot, String args) {
        ensure(c);
        return RootShell.get(slot).exec("sh " + SCRIPT + " " + args, 20000);
    }

    static Map<String, String> kv(String out) {
        Map<String, String> m = new HashMap<String, String>();
        if (out == null) return m;
        for (String line : out.split("\n")) {
            int i = line.indexOf('=');
            if (i > 0) m.put(line.substring(0, i).trim(), line.substring(i + 1).trim());
        }
        return m;
    }

    static boolean validPkg(String s) {
        return s != null && s.matches("[A-Za-z0-9._]{1,200}");
    }

    static boolean validNum(String s) {
        return s != null && s.matches("[0-9]{1,3}(\\.[0-9]{1,2})?");
    }

    static String modeName(String id) {
        if ("chill".equals(id)) return "Hemat";
        if ("turbo".equals(id) || "tourney".equals(id)) return "Performa";
        return "Seimbang";
    }

    static String normMode(String id) {
        if ("chill".equals(id) || "balance".equals(id) || "turbo".equals(id)) return id;
        return "turbo";
    }
}
