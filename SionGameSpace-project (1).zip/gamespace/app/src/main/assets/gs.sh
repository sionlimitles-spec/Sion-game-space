#!/system/bin/sh
# Sion Game Space - skrip root.
# Setiap perubahan dicatat di snapshot ($SNAP) dan dikembalikan oleh "restore".
# Pemakaian: sh gs.sh <perintah> [argumen]

D=${GS_DIR:-/data/local/tmp/gamespace}
SNAP=$D/snap
mkdir -p "$D" 2>/dev/null

kv() { echo "$1=$2"; }
pkg_ok() { case "$1" in ""|*[!A-Za-z0-9._]*) return 1 ;; esac; return 0; }
num_ok() { case "$1" in ""|*[!0-9.]*) return 1 ;; esac; return 0; }
host_ok() { case "$1" in ""|*[!A-Za-z0-9.-]*) return 1 ;; esac; return 0; }
empty_dash() { [ "$1" = "-" ] && echo "" || echo "$1"; }

# ---------- snapshot ----------
snap_del() { # awalan baris
  [ -f "$SNAP" ] || return 0
  grep -v "^$1" "$SNAP" > "$SNAP.t" 2>/dev/null
  mv "$SNAP.t" "$SNAP" 2>/dev/null
}

setnode() { # berkas nilai
  [ -e "$1" ] || return 1
  [ -w "$1" ] || chmod 0644 "$1" 2>/dev/null
  grep -q "^n|$1|" "$SNAP" 2>/dev/null || echo "n|$1|$(cat "$1" 2>/dev/null)" >> "$SNAP"
  echo "$2" > "$1" 2>/dev/null
}

setset() { # namespace kunci nilai
  grep -q "^s|$1|$2|" "$SNAP" 2>/dev/null || echo "s|$1|$2|$(settings get "$1" "$2" 2>/dev/null)" >> "$SNAP"
  settings put "$1" "$2" "$3" 2>/dev/null
}

restore_set() { # namespace kunci
  line=$(grep "^s|$1|$2|" "$SNAP" 2>/dev/null | head -n 1)
  [ -n "$line" ] || return 0
  old=${line#s|$1|$2|}
  if [ -z "$old" ] || [ "$old" = "null" ]; then settings delete "$1" "$2" >/dev/null 2>&1
  else settings put "$1" "$2" "$old" >/dev/null 2>&1; fi
  snap_del "s|$1|$2|"
}

restore_all() {
  [ -f "$SNAP" ] || { kv restored 0; return 0; }
  n=0
  while IFS='|' read -r k a b c <&3; do
    case "$k" in
      n) echo "$b" > "$a" 2>/dev/null; n=$((n + 1)) ;;
      s) if [ -z "$c" ] || [ "$c" = "null" ]; then settings delete "$a" "$b" >/dev/null 2>&1 </dev/null
         else settings put "$a" "$b" "$c" >/dev/null 2>&1 </dev/null; fi
         n=$((n + 1)) ;;
      d) cmd notification set_dnd off >/dev/null 2>&1 </dev/null; n=$((n + 1)) ;;
      w) cmd wifi force-low-latency-mode disabled >/dev/null 2>&1 </dev/null; n=$((n + 1)) ;;
      g) cmd game reset "$a" >/dev/null 2>&1 </dev/null; cmd game mode standard "$a" >/dev/null 2>&1 </dev/null; n=$((n + 1)) ;;
    esac
  done 3< "$SNAP"
  rm -f "$SNAP"
  kv restored "$n"
}

# ---------- frekuensi ----------
# frekuensi tersedia terdekat (di atas atau sama dengan) persen tertentu dari maksimum
pick_freq() { # direktori persen berkas-daftar berkas-max
  if [ -r "$1/$3" ]; then
    awk -v p="$2" '{for(i=1;i<=NF;i++){v=$i+0; if(v>0){f[++n]=v; if(v>m)m=v}}} END{if(!n)exit; t=m*p/100; b=m; for(i=1;i<=n;i++) if(f[i]>=t && f[i]<b) b=f[i]; printf "%d\n", b}' "$1/$3"
  elif [ -r "$1/$4" ]; then
    read -r m < "$1/$4"
    [ -n "$m" ] && echo $((m * $2 / 100))
  fi
}

cpu_min() {
  for p in /sys/devices/system/cpu/cpufreq/policy*; do
    [ -d "$p" ] || continue
    f=$(pick_freq "$p" "$1" scaling_available_frequencies cpuinfo_max_freq)
    [ -n "$f" ] && setnode "$p/scaling_min_freq" "$f"
  done
}

cpu_cap() {
  for p in /sys/devices/system/cpu/cpufreq/policy*; do
    [ -d "$p" ] || continue
    f=$(pick_freq "$p" "$1" scaling_available_frequencies cpuinfo_max_freq)
    [ -n "$f" ] && setnode "$p/scaling_max_freq" "$f"
  done
}

gpu_dirs() {
  for d in /sys/class/kgsl/kgsl-3d0/devfreq /sys/class/devfreq/*gpu* /sys/class/devfreq/*mali* /sys/class/devfreq/*kgsl*; do
    [ -d "$d" ] && echo "$d"
  done
}

gpu_min() {
  for d in $(gpu_dirs); do
    f=$(pick_freq "$d" "$1" available_frequencies max_freq)
    [ -n "$f" ] && setnode "$d/min_freq" "$f"
  done
}

# ---------- layar ----------
rates() {
  dumpsys display 2>/dev/null | grep -o 'fps=[0-9.]*' | sed 's/fps=//; s/\..*//' | sort -un | tr '\n' ',' | sed 's/,$//'
}

top_rate() { rates | tr ',' '\n' | tail -n 1; }

set_rate() { # hz | auto
  if [ "$1" = "auto" ]; then
    restore_set system peak_refresh_rate; restore_set system min_refresh_rate; restore_set system user_refresh_rate
    kv rate auto; return
  fi
  num_ok "$1" || { kv rate bad; return 1; }
  setset system peak_refresh_rate "$1"
  setset system min_refresh_rate "$1"
  [ "$(settings get system user_refresh_rate 2>/dev/null)" != "null" ] && setset system user_refresh_rate "$1"
  kv rate "$1"
}

# ---------- fokus ----------
focus_on() {
  if [ "$(settings get global zen_mode 2>/dev/null)" = "0" ] && ! grep -q '^d|' "$SNAP" 2>/dev/null; then
    echo "d|1" >> "$SNAP"
    cmd notification set_dnd priority >/dev/null 2>&1
  fi
  setset global heads_up_notifications_enabled 0
  setset system screen_brightness_mode 0
  kv focus 1
}

focus_off() {
  if grep -q '^d|' "$SNAP" 2>/dev/null; then cmd notification set_dnd off >/dev/null 2>&1; snap_del 'd|'; fi
  restore_set global heads_up_notifications_enabled
  restore_set system screen_brightness_mode
  kv focus 0
}

bright_lock() { # on | off
  if [ "$1" = "on" ]; then setset system screen_brightness_mode 0; else restore_set system screen_brightness_mode; fi
  kv bright "$1"
}

gesture_off() { # left | right | both
  case "$1" in left|both) setset secure back_gesture_inset_scale_left 0 ;; esac
  case "$1" in right|both) setset secure back_gesture_inset_scale_right 0 ;; esac
}

wifi_ll() { # on | off
  if [ "$1" = "on" ]; then
    grep -q '^w|' "$SNAP" 2>/dev/null || echo "w|1" >> "$SNAP"
    cmd wifi force-low-latency-mode enabled >/dev/null 2>&1
  else
    cmd wifi force-low-latency-mode disabled >/dev/null 2>&1
    snap_del 'w|'
  fi
  kv wifi "$1"
}

# ---------- memori ----------
ram_boost() {
  sync
  echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
  echo 1 > /proc/sys/vm/compact_memory 2>/dev/null
  am kill-all >/dev/null 2>&1
  awk '/MemAvailable/{printf "ram_free_mb=%d\n", $2/1024}' /proc/meminfo
}

protect() { # paket
  pkg_ok "$1" || return 1
  pid=$(pidof "$1" 2>/dev/null | cut -d' ' -f1)
  [ -n "$pid" ] || { kv protect 0; return 0; }
  echo -800 > "/proc/$pid/oom_score_adj" 2>/dev/null
  renice -n -6 -p "$pid" >/dev/null 2>&1
  kv protect "$pid"
}

# ---------- mode game Android ----------
gm() { # paket mode turun fps
  sdk=$(getprop ro.build.version.sdk)
  [ "${sdk:-0}" -ge 31 ] 2>/dev/null || return 0
  cmd game mode "$2" "$1" >/dev/null 2>&1
  if [ -n "$3" ] || [ -n "$4" ]; then
    m=2; case "$2" in battery) m=3 ;; standard) m=1 ;; esac
    cmd game set --mode "$m" ${3:+--downscale "$3"} ${4:+--fps "$4"} "$1" >/dev/null 2>&1
  fi
  grep -q "^g|$1" "$SNAP" 2>/dev/null || echo "g|$1" >> "$SNAP"
}

# ---------- terapkan / kembalikan ----------
apply() { # mode paket fokus turun fps refresh sisi
  mode=$1; pkg=$2
  focus=$(empty_dash "$3"); down=$(empty_dash "$4"); fps=$(empty_dash "$5"); rate=$(empty_dash "$6"); side=$(empty_dash "$7")
  pkg_ok "$pkg" || { kv apply bad; return 1; }
  [ -n "$down" ] && ! num_ok "$down" && down=""
  [ -n "$fps" ] && ! num_ok "$fps" && fps=""
  restore_all >/dev/null
  gmode=standard; r=""
  case "$mode" in
    chill)   cpu_cap 70; gmode=battery; r=60 ;;
    balance) ;;
    turbo|tourney) cpu_min 60; gpu_min 60; gmode=performance; r=top; wifi_ll on >/dev/null; ram_boost >/dev/null ;;
    *) kv apply mode-tidak-dikenal; return 1 ;;
  esac
  [ -n "$rate" ] && r=$rate
  case "$r" in top) r=$(top_rate) ;; esac
  [ -n "$r" ] && [ "$r" != "auto" ] && set_rate "$r" >/dev/null
  gm "$pkg" "$gmode" "$down" "$fps"
  [ "$focus" = "1" ] && focus_on >/dev/null
  [ -n "$side" ] && [ "$side" != "none" ] && gesture_off "$side"
  protect "$pkg" >/dev/null
  kv apply ok
  kv mode "$mode"
}

# ---------- pengukuran ----------
zones_list() {
  if [ ! -s "$D/zones" ]; then
    : > "$D/zones"
    for z in /sys/class/thermal/thermal_zone*; do
      [ -r "$z/type" ] || continue
      read -r ty < "$z/type"
      case "$ty" in
        *cpu*|*soc*|*tsens*|*big*|*little*|*mid*|*prime*|*mtktscpu*|*gpu*) echo "$z/temp" >> "$D/zones" ;;
      esac
    done
  fi
}

sf_latency() { # nama layer
  [ -n "$1" ] || return 0
  dumpsys SurfaceFlinger --latency "$1" 2>/dev/null | awk '
    NR==1 { next }
    $2>0 && $2<9e18 { n++; t[n]=$2 }
    END {
      if (n<2) { print "fps=0"; exit }
      last=t[n]; c=0
      for (i=1;i<=n;i++) if (t[i]>last-1e9) c++
      printf "fps=%d\n", c
      ft=""
      for (i=(n>31?n-30:2);i<=n;i++) ft=ft sprintf("%.1f,", (t[i]-t[i-1])/1e6)
      print "ft=" ft
    }'
}

fps_info() {
  pkg=$1
  layer=""; [ -s "$D/layer" ] && read -r layer < "$D/layer"
  case "$layer" in *"$pkg"*) ;; *) layer="" ;; esac
  miss=0; [ -s "$D/miss" ] && read -r miss < "$D/miss"
  out=$(sf_latency "$layer")
  case "$out" in
    fps=0*|"")
      miss=$((miss + 1))
      if [ -z "$layer" ] || [ "$miss" -ge 5 ]; then
        layer=$(dumpsys SurfaceFlinger --list 2>/dev/null | grep -F "$pkg" | grep -v -E 'Background|Bounds|Letterbox|ActivityRecord' | tail -n 1)
        echo "$layer" > "$D/layer"
        miss=0
        out=$(sf_latency "$layer")
      fi ;;
    *) miss=0 ;;
  esac
  echo "$miss" > "$D/miss"
  [ -n "$out" ] && echo "$out" || kv fps 0
}

metrics() { # paket
  zones_list
  tc=0
  while IFS= read -r z; do
    read -r v < "$z" 2>/dev/null || continue
    [ "$v" -gt 1000 ] 2>/dev/null && v=$((v / 1000))
    [ "$v" -gt "$tc" ] 2>/dev/null && [ "$v" -lt 120 ] && tc=$v
  done < "$D/zones"
  kv temp_cpu "$tc"
  B=/sys/class/power_supply/battery
  if [ -r "$B/temp" ]; then read -r bt < "$B/temp"; kv temp_bat $((bt / 10)); fi
  if [ -r "$B/capacity" ]; then read -r bc < "$B/capacity"; kv bat "$bc"; fi
  if [ -r "$B/current_now" ]; then read -r cn < "$B/current_now"; kv cur_ma $((cn / 1000)); fi
  awk '/MemTotal/{t=$2}/MemAvailable/{a=$2}END{if(t>0) printf "ram_used=%d\nram_free_mb=%d\n", (t-a)*100/t, a/1024}' /proc/meminfo
  for g in /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage; do
    if [ -r "$g" ]; then read -r gv < "$g"; kv gpu "${gv%%[!0-9]*}"; fi
  done
  read -r _ u n s i io irq sirq st _ < /proc/stat
  kv cpu_idle $((i + io))
  kv cpu_total $((u + n + s + i + io + irq + sirq + st))
  pkg_ok "$1" && fps_info "$1"
}

fg() {
  dumpsys window 2>/dev/null | grep -m1 -E 'mCurrentFocus|mFocusedApp' | sed -n 's/.* \([A-Za-z0-9._]*\)\/[A-Za-z0-9._$]*.*/\1/p' | head -n 1
}

caps() {
  kv root "$(id -u)"
  kv sdk "$(getprop ro.build.version.sdk)"
  kv soc "$(getprop ro.soc.model)$(getprop ro.board.platform | sed 's/^/ /')"
  kv rates "$(rates)"
  n=0; for p in /sys/devices/system/cpu/cpufreq/policy*; do [ -d "$p" ] && n=$((n + 1)); done
  kv cpu_policies "$n"
  kv gpu "$(gpu_dirs | wc -l)"
  cmd -l 2>/dev/null | grep -qx game && kv gamemode 1 || kv gamemode 0
  [ "$(settings get secure back_gesture_inset_scale_left 2>/dev/null)" != "" ] && kv gesture 1
}

# ---------- alat ----------
launch() {
  pkg_ok "$1" || { kv launch bad; return 1; }
  c=$(cmd package resolve-activity --brief -c android.intent.category.LAUNCHER "$1" 2>/dev/null | tail -n 1)
  case "$c" in
    */*) am start -n "$c" >/dev/null 2>&1 ;;
    *) monkey -p "$1" -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1 ;;
  esac
  kv launch ok
}

shot() {
  mkdir -p /sdcard/Pictures/GameSpace 2>/dev/null
  f=/sdcard/Pictures/GameSpace/shot_$(date +%Y%m%d_%H%M%S).png
  screencap -p "$f" 2>/dev/null
  [ -s "$f" ] && kv shot "$f" || kv shot gagal
}

rec() { # start | stop | status
  case "$1" in
    start)
      pidof screenrecord >/dev/null 2>&1 && { kv rec 1; return; }
      mkdir -p /sdcard/Movies/GameSpace 2>/dev/null
      f=/sdcard/Movies/GameSpace/rec_$(date +%Y%m%d_%H%M%S).mp4
      nohup screenrecord --bit-rate 12000000 --time-limit 180 "$f" >/dev/null 2>&1 &
      echo "$f" > "$D/recfile"
      kv rec 1 ;;
    stop)
      pid=$(pidof screenrecord 2>/dev/null)
      [ -n "$pid" ] && kill -2 $pid 2>/dev/null
      kv rec 0
      kv file "$(cat "$D/recfile" 2>/dev/null)" ;;
    *) pidof screenrecord >/dev/null 2>&1 && kv rec 1 || kv rec 0 ;;
  esac
}

perm() {
  P=com.sion.gamespace
  appops set "$P" SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1
  pm grant "$P" android.permission.POST_NOTIFICATIONS >/dev/null 2>&1
  pm grant "$P" android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1
  cmd notification allow_dnd "$P" >/dev/null 2>&1
  cmd deviceidle whitelist "+$P" >/dev/null 2>&1
  appops set "$P" RUN_IN_BACKGROUND allow >/dev/null 2>&1
  kv perm ok
}

ping_ms() {
  host_ok "$1" || return 1
  ping -c 1 -W 1 "$1" 2>/dev/null | sed -n 's/.*time=\([0-9.]*\).*/\1/p' | head -n 1
}

cmd_name=$1; shift 2>/dev/null
case "$cmd_name" in
  caps) caps ;;
  fg) fg ;;
  apply) apply "$@" ;;
  restore) restore_all ;;
  protect) protect "$1" ;;
  metrics) metrics "$1" ;;
  ram) ram_boost ;;
  focus) case "$1" in on) focus_on ;; *) focus_off ;; esac ;;
  bright) bright_lock "$1" ;;
  wifi) wifi_ll "$1" ;;
  refresh) set_rate "$1" ;;
  rates) rates ;;
  launch) launch "$1" ;;
  shot) shot ;;
  rec) rec "$1" ;;
  perm) perm ;;
  ping) ping_ms "$1" ;;
  *) echo "gs.sh caps|fg|apply|restore|protect|metrics|ram|focus|bright|wifi|refresh|rates|launch|shot|rec|perm|ping"; exit 1 ;;
esac
