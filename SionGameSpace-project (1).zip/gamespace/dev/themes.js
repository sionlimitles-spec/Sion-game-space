const { chromium } = require('playwright');
const fs = require('fs');
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1.5 });
  const page = await ctx.newPage();
  const errs = [];
  page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  page.on('pageerror', e => errs.push('PAGEERR ' + e.message));
  await page.addInitScript(fs.readFileSync('/tmp/claude-0/work/gamespace/dev/mock.js', 'utf8'));
  await page.goto('http://127.0.0.1:8777/index.html');
  await page.waitForTimeout(2600);
  const out = '/tmp/claude-0/work/gamespace/dev/';
  for (const [i, m] of [['chill', 'Hemat'], ['balance', 'Seimbang'], ['turbo', 'Performa']].entries()) {
    await page.click('#modes button[data-v=' + m[0] + ']');
    await page.waitForTimeout(1300);
    await page.screenshot({ path: out + 't' + (i + 1) + '_' + m[0] + '.png' });
  }
  await page.click('.game[data-pkg="com.tencent.ig"]');
  await page.waitForTimeout(900);
  await page.screenshot({ path: out + 't4_sheet.png' });
  console.log('ERRS', JSON.stringify(errs));
  await b.close();
})();
