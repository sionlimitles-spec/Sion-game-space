(function () {
  function ico(c1, c2, ch) {
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' + c1 + '"/><stop offset="1" stop-color="' + c2 + '"/></linearGradient></defs><rect width="96" height="96" rx="22" fill="url(#g)"/><text x="48" y="64" font-size="46" text-anchor="middle" fill="#fff" font-family="sans-serif" font-weight="800">' + ch + '</text></svg>';
    return 'data:image/svg+xml;base64,' + btoa(svg);
  }
  var ICON = { 'com.mobile.legends': ico('#ff7a18', '#af002d', 'M'), 'com.tencent.ig': ico('#7ddc52', '#1e6b3a', 'P'), 'com.miHoYo.GenshinImpact': ico('#7aa7ff', '#4b2fb0', 'G'), 'com.garena.game.ff': ico('#ffb347', '#d6336c', 'F'), 'com.supercell.clashofclans': ico('#ffd43b', '#e8590c', 'C'), 'com.roblox.client': ico('#ff6b6b', '#c92a2a', 'R') };
  var now = Date.now(), H = 3600e3, D = 24 * H;
  var st = {
    root: true, overlay: false, running: false, game: '', sdk: 34,
    cfg: { defaultMode: 'turbo', side: 'right', handleY: .38, handleLen: 150, edgeMode: 'edge', stealth: false, hud: true, hudCorner: 'tl', hudFps: true, hudTemp: true, hudPing: true, hudBat: false, hudOpacity: 85, pingHost: '1.1.1.1', guard: true, guardTemp: 48, autoStart: true, focus: true, haptic: true },
    games: {
      'com.mobile.legends': { name: 'Mobile Legends', mode: '', focus: true, down: '', fps: '', refresh: '' },
      'com.tencent.ig': { name: 'PUBG MOBILE', mode: 'tourney', focus: true, down: '0.8', fps: '60', refresh: '' },
      'com.miHoYo.GenshinImpact': { name: 'Genshin Impact', mode: 'turbo', focus: true, down: '', fps: '', refresh: '' },
      'com.garena.game.ff': { name: 'Free Fire', mode: '', focus: true, down: '', fps: '', refresh: '' }
    }
  };
  var M = ['com.mobile.legends', 'com.tencent.ig', 'com.miHoYo.GenshinImpact', 'com.garena.game.ff'];
  var sess = [];
  [[.1, 0, 0, 3300, 59, 52, 41, 6, 24, 'turbo'], [.9, 1, 1, 5400, 57, 49, 44, 9, 31, 'tourney'], [1.2, 0, 0, 2400, 60, 55, 40, 4, 22, 'turbo'], [2.1, 2, 2, 4100, 45, 38, 46, 11, 28, 'turbo'], [2.8, 0, 0, 1800, 60, 54, 39, 3, 25, 'chill'], [3.6, 1, 1, 6900, 58, 50, 45, 12, 35, 'tourney'], [4.3, 3, 3, 2700, 60, 56, 38, 4, 20, 'balance'], [5.4, 0, 0, 3900, 59, 53, 42, 7, 26, 'turbo']].forEach(function (x) {
    sess.push({ pkg: M[x[1]], name: st.games[M[x[1]]].name, start: now - x[0] * D, dur: x[3], avg: x[4], low: x[5], temp: x[6], drop: x[7], ping: x[8], mode: x[9] });
  });
  var apps = [['Mobile Legends', 'com.mobile.legends', 1], ['PUBG MOBILE', 'com.tencent.ig', 1], ['Genshin Impact', 'com.miHoYo.GenshinImpact', 1], ['Free Fire', 'com.garena.game.ff', 1], ['Clash of Clans', 'com.supercell.clashofclans', 1], ['Roblox', 'com.roblox.client', 1], ['Chrome', 'com.android.chrome', 0], ['WhatsApp', 'com.whatsapp', 0], ['YouTube', 'com.google.android.youtube', 0], ['Spotify', 'com.spotify.music', 0]].map(function (a) { return { name: a[0], pkg: a[1], game: !!a[2], added: false }; });
  function reply(cb, o, ms) { setTimeout(function () { window.__gs_cb(cb, typeof o === 'string' ? o : JSON.stringify(o)); }, ms || 60); }
  window.GS = {
    api: function (cmd, json, cb) {
      var a = {}; try { a = JSON.parse(json || '{}'); } catch (e) { }
      window.__calls = window.__calls || []; window.__calls.push([cmd, a]);
      switch (cmd) {
        case 'state': return reply(cb, JSON.parse(JSON.stringify(st)));
        case 'apps': return reply(cb, apps, 200);
        case 'icon': return reply(cb, JSON.stringify(ICON[a.pkg] || ''), 50);
        case 'sessions': return reply(cb, sess);
        case 'perm': st.overlay = true; return reply(cb, { ok: true }, 400);
        case 'rootcheck': return reply(cb, { root: st.root }, 300);
        case 'service': st.running = !!a.on; return reply(cb, { ok: true }, 200);
        case 'addGame': var g = { name: (apps.filter(function (x) { return x.pkg === a.pkg; })[0] || {}).name || a.pkg, mode: '', focus: true, down: '', fps: '', refresh: '' }; st.games[a.pkg] = g; return reply(cb, { ok: true, conf: g });
        case 'removeGame': delete st.games[a.pkg]; return reply(cb, { ok: true });
        case 'setGame': st.games[a.pkg][a.key] = a.value; return reply(cb, { ok: true });
        case 'setCfg': st.cfg[a.key] = a.value; return reply(cb, { ok: true });
        case 'mode': st.cfg.defaultMode = a.id; return reply(cb, { ok: true });
        case 'clearSessions': sess.length = 0; return reply(cb, { ok: true });
        case 'launch': if (st.running) st.game = a.pkg; return reply(cb, { ok: true });
        case 'testHandle': return reply(cb, { ok: st.overlay, why: st.overlay ? undefined : 'overlay' });
        default: return reply(cb, { ok: true });
      }
    }
  };
  window.__mock = { st: st };
})();
